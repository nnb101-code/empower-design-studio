# GlattTrack v10.38 — הכל בקובץ אחד · Everything in one file

20.10.2026 · שרת 02 + בדיקות 03: **192/192** · מרכז תמיכה: **32/32**

> ⚠️ **עדיין לא למפעל אמיתי עד שסבבי הבדיקה יסתיימו.** · Not for a real plant yet, until the review rounds are finished.

## מה יש בכל תיקייה · What is in each folder

| תיקייה · Folder | מה יש בה · What is in it |
|---|---|
| `1-app` | קובץ התוכנה `kosher-app-v10.38.html`. הכלי `make-plant-build.py` מכין ממנו גרסה למפעל. · The app file, plus the tool that makes the plant build. |
| `2-server-update` | **עדכון שרת קיים.** הקבצים 00 → 01 → 02 → 03 לפי `INSTALL-HE.md`. · **Update an existing server.** Run 00 → 01 → 02 → 03 as in INSTALL-HE.md. |
| `3-server-new-from-zero` | **שרת חדש (ריק).** מריצים 1 (כל השרת), ואז 2 (בדיקה, 192/192), ואז 3 (בדיקת אבטחה). · **A new empty server.** Run 1 (the whole server), then 2 (the test), then 3 (the security check). |
| `4-plant-server` | הסקריפטים של שרת המפעל: התקנה, גיבוי, שרת חלופי, UPS, ממסר מדפסות וסורקים, דיווח למרכז, עדכון. · The plant server scripts. |
| `5-support-center` | מרכז התמיכה של היצרן: SQL, בדיקה, הדף, ותיקיית ההעלאה. · The manufacturer's support center. |
| `6-kashrut-marks-and-stickers` | סימני כשרות ומדבקות לדוגמה. · Kashrut marks and sample stickers. |
| `7-docs` | מצב הפרויקט, הדוח של סבב 3, כל הממצאים, השינויים. · Status, the round-3 report, findings, changes. |
| `8-tests` | תוצאות הבדיקות ובדיקות הדפדפן. · Test results and browser tests. |

## הכי חשוב · Most important
- **רק עדכון אפליקציה:** מחליפים את הקובץ שב-`1-app`. · **App only:** replace the file from `1-app`.
- **עדכון שרת:** מריצים את 02, ואחריו 03. צריך לראות `PASSED — 192 of 192`. · **Server update:** run 02, then 03. You should see `PASSED — 192 of 192`.
- **⚠️ אחרי עדכון השרת, לעדכן את כל הטאבלטים לפני העבודה.** · Update all tablets before work.

## מה לא בזיפ (בכוונה) · Not in the zip (on purpose)
- **מפתחות פרטיים** (`gt-release-private.pem`) **וסודות**. יש בזיפ רק ערכים ציבוריים: כתובת השרת ומפתח ה-anon. · Private keys and secrets: only public values are inside.
- **הסרטונים** (155MB). · The videos.
- **גרסאות ישנות** של האפליקציה. · Old app versions.
