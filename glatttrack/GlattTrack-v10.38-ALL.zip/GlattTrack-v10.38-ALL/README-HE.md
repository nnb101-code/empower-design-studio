# GlattTrack v10.38 — הכל בקובץ אחד · Everything in one file

01.11.2026 · שרת המפעל **197/197** · מרכז היצרן **35/35**

> ⚠️ **עדיין לא למפעל אמיתי עד שסבבי הבדיקה יסתיימו.** · Not for a real plant yet, until the review rounds are finished.

**מתחילים כאן:** `0-SOFTWARE-OVERVIEW.md` — הסבר מלא על התוכנה: מה היא עושה, כל המסכים, כללי הכשרות, מדבקות וברקוד, מבנה טכני, אבטחה, רישיונות, התקנה, בדיקות, מה לא גמור, ומה לבדוק.
**Start here:** `0-SOFTWARE-OVERVIEW.md` — the full explanation of the software.

**לבדיקה בצ'אט אחר:** מעלים את הזיפ ומדביקים את התוכן של `PROMPT-FOR-REVIEW.txt`.
**For a review in another chat:** upload the zip and paste `PROMPT-FOR-REVIEW.txt`.

| תיקייה · Folder | מה יש בה · What is in it |
|---|---|
| `1-app` | קובץ התוכנה · the app file |
| `2-server-update` | עדכון שרת קיים (00 → 01 → 02 → 03) · update an existing server |
| `3-server-new-from-zero` | שרת חדש, כל השרת בקובץ אחד · a new server, the whole server in one file |
| `4-plant-server` | הסקריפטים של שרת המפעל (Linux) · the plant server scripts |
| `5-support-center` | מרכז היצרן · the manufacturer center |
| `6-kashrut-marks-and-stickers` | סימני כשרות ומדבקות לדוגמה · marks and sample stickers |
| `7-docs` | מסמכים ודוחות בדיקה · documents and review reports |
| `8-tests` | תוצאות בדיקות ובדיקות דפדפן · test results and browser tests |

**לא בזיפ (בכוונה):** מפתחות פרטיים וסודות (בדפים רק ערכים ציבוריים: כתובת ומפתח anon), הסרטונים, גרסאות ישנות.
**Not in the zip (on purpose):** private keys and secrets (pages hold public values only), the videos, old versions.
