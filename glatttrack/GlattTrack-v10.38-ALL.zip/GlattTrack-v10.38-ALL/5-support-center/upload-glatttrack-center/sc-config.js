// the manufacturer's support center project (public values: the URL and the anon key)
window.SC_SERVER = { url: 'https://xvlucjdyypbexclkopwn.supabase.co', anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh2bHVjamR5eXBiZXhjbGtvcHduIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwOTc3MDAsImV4cCI6MjEwNzY3MzcwMH0.8sXIU_cmb9fOApBIZwKYsp-KKEfXrE3Uh-sLQrdm34Y' };
