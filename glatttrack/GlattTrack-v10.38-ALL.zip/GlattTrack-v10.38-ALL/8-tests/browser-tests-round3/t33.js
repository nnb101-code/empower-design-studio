// (§47) the kashrut part from the server: the team leader's tablet makes the marks; the stamps station prints
// through the plant server (one-time numbers, the server's band and barcode); the nikur takes a piece only with its number
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = process.env.APP || '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
const prods = JSON.stringify([
  {id:'tongue',he:'לשון',on:true,pre:'head',n:1,post:'parts',m:1,nikur:'small',builtin:true},
  {id:'cheeks',he:'לחיים',on:true,pre:'head',n:2,post:'parts',m:2,nikur:'small',builtin:true},
  {id:'sides',he:'צדדים',on:true,pre:'head',n:2,post:'stamps',m:6,nikur:'big',builtin:true},
  {id:'lung',he:'ריאה',on:true,pre:'head',n:1,post:'none',m:0,nikur:'none',builtin:true},
  {id:'legs',he:'רגליים',on:true,pre:'legs',n:2,post:'legs',m:0,nikur:'none',builtin:true},
  {id:'tail',he:'זנב',on:true,pre:'none',n:0,post:'stamps',m:1,nikur:'small',builtin:true}]);
const seal = fs.readFileSync(__dirname + '/seal.b64', 'utf8').trim();
const out = {};
(async () => {
  execSync('bash ' + __dirname + '/../vid/rl.sh');
  const s0 = db(`select settings::text from settings_pilot where id=1;`);
  db(`update settings_pilot set settings = (settings - 'printers') || jsonb_build_object('products', '${prods}'::jsonb, 'nikurSmallScreen', false,
        'printers', '[{"id":"pz","name":"Zebra","conn":"network","ip":"192.168.1.77","port":9100}]'::jsonb,
        'screenDevices', '{"stamps":{"printer":"pz"}}'::jsonb, 'customSeals', jsonb_build_object('glatt', '${seal}')) where id=1;`);
  db(`select _do_board_reset('t33', null);`);
  db(`begin; select set_config('gt.reset_in_progress','true',true);
    update animals_pilot set slaughter='slaughtered', slaughter_time=(extract(epoch from now())*1000)::bigint, eso_checked=true, eso_result='ok', legs_stickers=true, head_stickers=true, inner_status='confirmed', outer_status='glatt', outer_time=1 where id in (0,1,2);
    update animals_pilot set parts_scanned=true where id in (0,1,2); commit;`);
  db(`delete from print_marks;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const open = async (init) => { const ctx = await b.newContext({ viewport:{width:900,height:1200} }); await ctx.addInitScript(init);
    await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
    const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
    await p.goto('http://localhost:8083/'); await p.waitForTimeout(6000); return p; };
  // 1. before the team leader's screen opens: the network print waits for the mark
  const st = await open(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-stamps-live-0000000000000001'); localStorage.setItem('ks_kiosk_role','stamps'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_stamps_001'); });
  out.before = await st.evaluate(async()=>{ let m=0; const r=await gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; }); return {r, m, msg:(document.getElementById('gtPrintMsg')||{}).textContent||''}; });
  // 2. the team leader's screen: the marks are made by themselves
  const L = await open(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true; localStorage.setItem('ks_lang_by_screen', JSON.stringify({scNav:'he',scManager:'he'})); });
  await L.evaluate(()=>{ document.querySelectorAll('.overlay.open').forEach(o=>o.classList.remove('open')); mgrEnter(); }); await L.waitForTimeout(1000);
  await L.fill('#loginCodeInput','e2e-tl-code-7731'); await L.evaluate(()=>[...document.querySelectorAll('#loginModal button')].pop().click()); await L.waitForTimeout(6000);
  await L.evaluate(()=>{ try{ mgrTab('settings'); }catch(e){} }); await L.waitForTimeout(6000);
  out.marks = db(`select string_agg(status || ':' || rows_n, ',' order by status) from print_marks;`);
  // 3. the stamps station prints again: through the plant server (the job is "sent" here by the test, no printer)
  const n0 = Number(db(`select coalesce(max(id),0) from print_jobs;`));
  const marker = setInterval(()=>{ try{ db(`update print_jobs set status='sent', sent_at=now() where status='new';`); }catch(e){} }, 700);
  out.after = await st.evaluate(async()=>{ let m=0; const r=await gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; }); return {r, m}; });
  clearInterval(marker);
  db(`begin; select set_config('gt.reset_in_progress','true',true); update animals_pilot set stamped=true, stamped_as='glatt' where id=2; commit;`);   // what the station's commit sends
  const job = db(`select id || ' ' || data from print_jobs where id > ${n0} order by id desc limit 1;`);
  const zpl = Buffer.from(job.split(' ')[1] || '', 'base64').toString('utf8');
  fs.writeFileSync(__dirname + '/t33.zpl', zpl);
  out.labels = (zpl.match(/\^XA/g)||[]).length;
  out.hasQR = /\^BQN,2,\d+\^FDMA,BH\|N:3\|/.test(zpl); out.hasBand = zpl.includes(db(`select left(gfa, 60) from print_marks where status='glatt';`));
  out.tickets = db(`select count(*) || ' ' || count(job_id) from print_tickets where animal_id = 2;`);
  const tail = (zpl.match(/\^FDMA,(BH\|N:3\|[^\^]*\|P:tail\|[^\^]*)\^FS/)||[])[1] || '';
  out.tail = tail;
  // 4. the nikur: the tail piece without its number (a copy) — refused; with it — in
  const nk = await open(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-nikur-big-000000000000000000'); localStorage.setItem('ks_kiosk_role','nikur'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_nikur_0001'); });
  await nk.evaluate(()=>{ try{ supLogin(); }catch(e){} }); await nk.waitForTimeout(3000);
  out.nkNoT = await nk.evaluate(async c=>{ await nkScan(c); await new Promise(z=>setTimeout(z,2500)); return document.getElementById('nkResult').innerText; }, tail.replace(/\|T:[A-Z2-9]+/, ''));
  out.nkFake = await nk.evaluate(async c=>{ await nkScan(c); await new Promise(z=>setTimeout(z,2500)); return document.getElementById('nkResult').innerText; }, tail.replace(/\|T:[A-Z2-9]+/, '|T:ABCDEFGHJK'));
  out.nkOk = await nk.evaluate(async c=>{ await nkScan(c); await new Promise(z=>setTimeout(z,2500)); return document.getElementById('nkResult').innerText; }, tail);
  await b.close();
  db(`update settings_pilot set settings = '${s0.replace(/'/g, "''")}'::jsonb where id=1;`);
  console.log(JSON.stringify(out, null, 1));
  const pass = out.before.r===false && out.before.m===0 && /סימן הכשרות עוד לא הוכן|kashrut mark is not ready/.test(out.before.msg) && /glatt:/.test(out.marks||'')
    && out.after.r===true && out.after.m===1 && out.labels===7 && out.hasQR && out.hasBand && /\|T:[A-Z2-9]{10}$/.test(tail)
    && /לא מוכרת|not recognized/.test(out.nkNoT) && /לא מוכרת|not recognized/.test(out.nkFake) && /✓/.test(out.nkOk);
  console.log(pass ? 'PASSED — t33 server-built kosher stickers' : 'FAILED — t33');
  process.exit(pass?0:1);
})();
