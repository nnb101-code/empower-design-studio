// (audit A3) test mode, no printer: the animal is marked only when the virtual stickers are on the screen; a second tap waits
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
(async () => {
  db(`update settings_pilot set settings = (settings - 'printers') || jsonb_build_object('screenDevices', '{}'::jsonb) where id=1;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport:{width:800,height:900} });
  await ctx.addInitScript(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-stamps-live-0000000000000001'); localStorage.setItem('ks_kiosk_role','stamps'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_stamps_001'); });
  await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
  const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
  await p.goto('http://localhost:8083/'); await p.waitForTimeout(7000);
  const res = await p.evaluate(async()=>{
    const out={};
    let m=0; out.ok = { r: await gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; }), m, n:_gtVP.items.length };
    const keep=window.gtStickerCanvas; window.gtStickerCanvas=async()=>{ throw new Error('draw failed'); };
    m=0; const n0=_gtVP.items.length; out.fail = { r: await gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; }), m, added:_gtVP.items.length-n0 };
    window.gtStickerCanvas=keep;
    m=0; const a=gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; }), c=gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; });
    out.double = { r1: await a, r2: await c, m };
    return out; });
  console.log(JSON.stringify(res));
  const pass = res.ok.r===true && res.ok.m===1 && res.ok.n>0 && res.fail.r===false && res.fail.m===0 && res.double.r1===true && res.double.r2===false && res.double.m===1;
  console.log(pass ? 'PASSED — t31 test-mode virtual print' : 'FAILED — t31');
  await b.close(); process.exit(pass?0:1);
})();
