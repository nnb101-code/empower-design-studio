const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs=require('fs'); const s=fs.readFileSync('/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html','utf8');
const pick=n=>{ const i=s.indexOf('function '+n+'('); let d=0,j=s.indexOf('{',i); for(;j<s.length;j++){ if(s[j]=='{')d++; else if(s[j]=='}'){d--; if(!d)break;} } return s.slice(i,j+1); };
(async()=>{ const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'}); const p=await b.newPage();
  const r=await p.evaluate(([e,j])=>{ eval(e+';'+j+';window.escapeHtml=escapeHtml;window._jsArg=_jsArg;'); window.got=[]; window.gtPieToggle=k=>got.push(k); window.hacked=0;
    const keys=["a'b","x');hacked=1;('",'q"w<b>'];
    document.body.innerHTML=keys.map(k=>`<input type="checkbox" onclick="gtPieToggle(${_jsArg(k)})">`).join('');
    document.querySelectorAll('input').forEach(i=>i.click()); return {got:window.got, hacked:window.hacked, ok:JSON.stringify(window.got)===JSON.stringify(keys)}; },[pick('escapeHtml'),pick('_jsArg')]);
  console.log(JSON.stringify(r)); console.log(r.ok&&!r.hacked?'PASSED — A-2 pie key':'FAILED'); await b.close(); })();
