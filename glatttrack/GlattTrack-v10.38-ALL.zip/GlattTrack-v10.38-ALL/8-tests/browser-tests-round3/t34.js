// (owner) test mode: a virtual sticker is a real sticker — its barcode is read back by the app's own reader with
// everything in it (kosher: number, day, part, piece, board, kashrut, print number; legs: number, day, shochet, time...)
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
(async () => {
  const s0 = db(`select settings::text from settings_pilot where id=1;`);
  db(`update settings_pilot set settings = (settings - 'printers') || jsonb_build_object('screenDevices', '{}'::jsonb) where id=1;`);
  db(`select _do_board_reset('t34', null);`);
  db(`begin; select set_config('gt.reset_in_progress','true',true);
    update animals_pilot set slaughter='slaughtered', slaughtered_by='משה כהן', inner_by='יוסף לוי', inner_time=(extract(epoch from now())*1000)::bigint, outer_by='דוד אברהם', slaughter_time=(extract(epoch from now())*1000)::bigint, eso_checked=true, eso_result='ok', legs_stickers=true, head_stickers=true, inner_status='confirmed', outer_status='glatt', outer_time=1, parts_scanned=true where id = 2; commit;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport:{width:900,height:1200} });
  await ctx.addInitScript(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-stamps-live-0000000000000001'); localStorage.setItem('ks_kiosk_role','stamps'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_stamps_001'); });
  await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
  const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
  await p.goto('http://localhost:8083/'); await p.waitForTimeout(7000);
  const out = await p.evaluate(async()=>{
    const read = src => new Promise(res=>{ const im=new Image(); im.onload=()=>res(_gtZxRead(im, im.width, im.height, 0, 0, im.width, im.height, 1400)); im.onerror=()=>res(null); im.src=src; });
    _gtVP.items=[];
    let m=0; const ok=await gtPrintGate('stamps', _gtStampsJobs(2), ()=>{ m++; });
    const kosher=[]; for(const it of _gtVP.items) kosher.push({label:it.t, code:await read(it.src)});
    _gtVP.items=[]; await gtVirtualPrint([{idx:2, kind:'legs', copies:1}]);
    const legs=await read(_gtVP.items[0].src);
    return {ok, m, kosher, legs};
  });
  await b.close();
  db(`update settings_pilot set settings = '${s0.replace(/'/g, "''")}'::jsonb where id=1;`);
  console.log(JSON.stringify(out, null, 1));
  const kOk = out.kosher.length >= 7 && out.kosher.every(k => /^BH\|N:3\|D:\d{4}-\d{2}-\d{2}\|TM:\d\d:\d\d\|SH:משה כהן\|IN:יוסף לוי\|IT:\d\d:\d\d\|OUT:דוד אברהם\|OT:\d\d:\d\d\|P:[a-z_]+\|I:\d+\|B:\d+\|K:גלאט · Glatt\|S:glatt\|T:[A-Z2-9]{10}$/.test(k.code||''));
  const lOk = /^BH\|N:3\|D:\d{4}-\d{2}-\d{2}\|/.test(out.legs||'') && /SH:משה כהן/.test(out.legs||'');
  console.log(out.ok && out.m===1 && kOk && lOk ? 'PASSED — t34 virtual stickers carry real, readable barcodes' : 'FAILED — t34');
})();
