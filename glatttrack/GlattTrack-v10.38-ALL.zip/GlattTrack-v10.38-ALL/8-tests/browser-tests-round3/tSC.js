const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const OUT=process.argv[2]; const R={};
(async()=>{ const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'}); const p=await b.newPage({viewport:{width:1100,height:760}});
 const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',d=>d.accept());
 await p.goto('http://localhost:8090/'); await p.waitForTimeout(800);
 // code field: left to right, eye, Hebrew-keyboard warning
 await p.fill('#code','שדג'); await p.dispatchEvent('#code','input');
 R.dir=await p.$eval('#code',e=>getComputedStyle(e).direction); R.kb=await p.$eval('#code_kb',e=>e.classList.contains('on'));
 await p.fill('#code','abc-123'); await p.dispatchEvent('#code','input'); R.kbOff=!(await p.$eval('#code_kb',e=>e.classList.contains('on')));
 await p.click('.eye'); R.eyeText=await p.$eval('#code',e=>e.type); await p.screenshot({path:OUT+'/1-login-he.png'});
 await p.click('.eye'); R.eyeBack=await p.$eval('#code',e=>e.type);
 // English
 await p.click('#lg_en'); await p.waitForTimeout(300); R.htmlDir=await p.evaluate(()=>document.documentElement.dir); R.loginEn=(await p.innerText('main')).slice(0,80);
 await p.fill('#code','owner-test-code-1'); await p.click('.eye'); await p.screenshot({path:OUT+'/2-login-en.png'});
 await p.evaluate(()=>doLogin()); await p.waitForTimeout(1500); R.tabs=await p.innerText('#tabs');
 await p.evaluate(()=>go('staff')); await p.waitForTimeout(1200); R.recBefore=(await p.innerText('main')).includes('You have no recovery code');
 await p.evaluate(()=>newRecovery()); await p.waitForTimeout(1500); const rec=await p.$eval('.rec',e=>e.textContent).catch(()=>null); R.rec=rec;
 await p.screenshot({path:OUT+'/3-staff-recovery-en.png', fullPage:true});
 // A: new code for the viewer-less: give the admin itself? give a new member
 await p.fill('#sn','Support Dana'); await p.fill('#sc','support-dana-01'); await p.evaluate(()=>sadd()); await p.waitForTimeout(1200);
 const sid=await p.evaluate(async()=>{ const d=await rpc('sc_staff_list',{p_token:TOK}); return d.staff.find(s=>s.name==='Support Dana').id; });
 await p.evaluate(id=>{ NEWC=id; showStaff(); }, sid); await p.waitForTimeout(1200);
 await p.fill('#nc1','support-dana-02'); await p.fill('#nc2','support-dana-0X'); await p.evaluate(()=>setCode()); await p.waitForTimeout(800); R.mismatch=await p.textContent('#ncerr');
 await p.fill('#nc2','support-dana-02'); await p.screenshot({path:OUT+'/4-new-code-en.png', fullPage:true}); await p.evaluate(()=>setCode()); await p.waitForTimeout(1500);
 R.danaOld=(await p.evaluate(()=>raw('sc_login',{p_code:'support-dana-01'}))).error; R.danaNew=(await p.evaluate(()=>raw('sc_login',{p_code:'support-dana-02'}))).ok;
 // B: forgot code → recovery (Hebrew)
 await p.click('#lg_he'); await p.waitForTimeout(1500); await p.evaluate(()=>logout()); await p.waitForTimeout(1500); await p.click('text=שכחתי את הקוד'); await p.waitForTimeout(300);
 await p.fill('#rc', rec.toLowerCase()); await p.fill('#rn1','owner-test-code-2'); await p.fill('#rn2','owner-test-code-2'); await p.screenshot({path:OUT+'/5-recover-he.png'});
 await p.evaluate(()=>doRecover()); await p.waitForTimeout(1500); R.afterRecover=(await p.innerText('main')).slice(0,120);
 R.ownerNew=(await p.evaluate(()=>raw('sc_login',{p_code:'owner-test-code-2'}))).ok; R.reuse=(await p.evaluate(r=>raw('sc_recover',{p_recovery:r,p_new_code:'owner-test-code-3'}),rec)).error;
 await p.screenshot({path:OUT+'/6-after-recover-he.png'});
 R.errs=errs; console.log(JSON.stringify(R,null,1));
 const ok=R.dir==='ltr'&&R.kb&&R.kbOff&&R.eyeText==='text'&&R.eyeBack==='password'&&R.htmlDir==='ltr'&&/Plants/.test(R.tabs)&&R.recBefore&&/^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$/.test(R.rec||'')
   &&/not the same/.test(R.mismatch)&&R.danaOld==='code_invalid'&&R.danaNew===true&&R.ownerNew===true&&R.reuse==='code_invalid'&&!errs.length;
 console.log(ok?'PASSED — center page':'FAILED'); await b.close(); })();
