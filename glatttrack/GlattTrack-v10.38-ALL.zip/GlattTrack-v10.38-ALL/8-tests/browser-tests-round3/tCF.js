// (audit A3) test mode, no printer: the animal is marked only when the virtual stickers are on the screen; a second tap waits
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
(async () => {
  db(`update settings_pilot set settings = (settings - 'printers') || jsonb_build_object('screenDevices', '{}'::jsonb) where id=1;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport:{width:800,height:900} });
  await ctx.addInitScript(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-stamps-live-0000000000000001'); localStorage.setItem('ks_kiosk_role','stamps'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_stamps_001'); });
  await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
  const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
  await p.goto('http://localhost:8083/'); await p.waitForTimeout(7000);
  await p.evaluate(()=>{ _showLoginModal('manager','code','scManagerLogin'); }); await p.waitForTimeout(400);
  await p.fill('#loginCodeInput','שלום'); await p.dispatchEvent('#loginCodeInput','input'); await p.waitForTimeout(100);
  const res = await p.evaluate(()=>{ const i=document.getElementById('loginCodeInput'), w=i.parentElement, k=w.nextElementSibling;
    const o={ wrapped:w.classList.contains('gt-cf'), dir:getComputedStyle(i).direction, kb:k&&k.classList.contains('on') };
    w.querySelector('.gt-eye').click(); o.shown=i.type; w.querySelector('.gt-eye').click(); o.hidden=i.type;
    i.value='abc123'; i.dispatchEvent(new Event('input')); o.kbOff=!k.classList.contains('on'); return o; });
  await p.fill('#loginCodeInput','abc-1234'); await p.evaluate(()=>document.querySelector('#loginCodeInput').parentElement.querySelector('.gt-eye').click());
  await p.screenshot({path: process.argv[2]+'/7-app-login.png'});
  await p.evaluate(()=>{ try{ _cancelLogin(); }catch(e){} gtStartFirstSetup(); }); await p.waitForTimeout(400);
  res.firstSetupHidden = await p.evaluate(()=>{ const i=document.getElementById('loginCodeInput'); return !!i && i.closest('div').style.display==='none' && i.offsetParent===null; });
  console.log(JSON.stringify(res));
  const pass = res.wrapped && res.dir==='ltr' && res.kb && res.shown==='text' && res.hidden==='password' && res.kbOff && res.firstSetupHidden;
  console.log(pass?'PASSED — app code field':'FAILED');
  await b.close(); process.exit(pass?0:1);
})();
