// (audit) XSS: hostile text in every stored name (workers, statuses, parts, printers, scanners, an animal's "by")
// must never run on any screen — team leader tabs and settings, stamps, parts, outer, nikur
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
const X1 = `<img src=x onerror="window.__xss=(window.__xss||0)+1">`;
const X2 = `'"><svg onload="window.__xss=(window.__xss||0)+1">`;
const sq = s => s.replace(/'/g, "''");
(async () => {
  execSync('bash ' + __dirname + '/../vid/rl.sh');
  const s0 = db(`select settings::text from settings_pilot where id=1;`);
  const S = JSON.parse(s0);
  const evil = JSON.parse(JSON.stringify(S));
  evil.users = [{name:X1, role:'outer', hasCode:false}, {name:X2, role:'stamps', hasCode:false}, {name:X1+'b', role:'parts', hasCode:false}, {name:X2+'n', role:'nikur', hasCode:false}];
  evil.customStatuses = [{key:'cx1', he:X1, en:X2, color:'#123456'}];
  evil.products = (S.products||[]).map(p => p.id==='tongue' ? Object.assign({}, p, {he:X1, en:X2}) : p);
  evil.printers = [{id:'p1', name:X1, conn:'network', ip:'192.168.1.50', port:9100}];
  evil.scanners = [{id:'s1', name:X2, conn:'bluetooth'}];
  db(`update settings_pilot set settings = '${sq(JSON.stringify(evil))}'::jsonb where id=1;`);
  db(`begin; select set_config('gt.reset_in_progress','true',true);
      update animals_pilot set slaughter='slaughtered', slaughter_time=(extract(epoch from now())*1000)::bigint, eso_checked=true, eso_result='ok',
             legs_stickers=true, head_stickers=true, inner_status='confirmed', inner_by='${sq(X2)}', outer_status='glatt', outer_time=1, outer_by='${sq(X1)}' where id=0; commit;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const results = {};
  const open = async (init) => { const ctx = await b.newContext({ viewport:{width:1000,height:1400} });
    await ctx.addInitScript(init);
    await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
    const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
    await p.goto('http://localhost:8083/'); await p.waitForTimeout(6000); return p; };
  const count = p => p.evaluate(()=>({xss: window.__xss||0, imgs: document.querySelectorAll('img[src="x"], svg[onload]').length,
    where: [...document.querySelectorAll('img[src="x"], svg[onload]')].map(e=>{ let a=e.parentElement; for(let i=0;i<3&&a&&!a.id;i++) a=a.parentElement; return (a&&a.id||'?')+' :: '+(e.parentElement?e.parentElement.outerHTML.slice(0,220):''); })}));
  // team leader: every tab and every settings card
  const L = await open(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true; localStorage.setItem('ks_lang_by_screen', JSON.stringify({scNav:'he',scManager:'he'})); });
  await L.evaluate(()=>{ document.querySelectorAll('.overlay.open').forEach(o=>o.classList.remove('open')); mgrEnter(); }); await L.waitForTimeout(1000);
  await L.fill('#loginCodeInput','e2e-tl-code-7731'); await L.evaluate(()=>[...document.querySelectorAll('#loginModal button')].pop().click()); await L.waitForTimeout(7000);
  for (const t of ['monitor','analysis','search','log','settings']) { await L.evaluate(t=>{ try{ mgrTab(t); }catch(e){} }, t); await L.waitForTimeout(1500); }
  await L.evaluate(()=>{ for(const f of ['mgrRenderDevices','mgrRenderPrintPreview','mgrRenderUsers','mgrRenderProducts','mgrRenderNcStatuses','mgrRenderSlKeys','mgrRenderStationsPanel','mgrRenderWeightControls','mgrRenderArchive','mgrRenderHealth'])
      { try{ if(typeof window[f]==='function') window[f](); }catch(e){} }
    document.querySelectorAll('.mgr-panel').forEach(p=>p.style.display='block'); });
  await L.waitForTimeout(1500);
  await L.evaluate(()=>{ try{ if(typeof gtSearchGo==='function') gtSearchGo('1'); }catch(e){} try{ if(typeof gtAnimalCard==='function') gtAnimalCard(0); }catch(e){} });
  await L.waitForTimeout(2000);
  results.leader = await count(L);
  results.leaderShown = await L.evaluate(()=>document.body.innerText.includes('<img src=x'));   // shown as text = escaped
  // stations
  const st = (tok, role, dev) => open(new Function(`if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','${tok}'); localStorage.setItem('ks_kiosk_role','${role}'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','${dev}');`));
  for (const [tok, role, dev] of [['tok-stamps-live-0000000000000001','stamps','e2e_stamps_001'], ['tok-outer-e2e-00000000000000001','outer','e2e_outer_0001'],
                                  ['tok-nikur-big-000000000000000000','nikur','e2e_nikur_0001']]) {
    const p = await st(tok, role, dev);
    await p.evaluate(()=>{ try{ supLogin(); }catch(e){} }); await p.waitForTimeout(3000);
    results[role] = await count(p);
  }
  await b.close();
  db(`update settings_pilot set settings = '${sq(s0)}'::jsonb where id=1;`);
  db(`begin; select set_config('gt.reset_in_progress','true',true); update animals_pilot set inner_by=null, outer_by=null where id=0; commit;`);
  console.log(JSON.stringify(results));
  const pass = Object.entries(results).every(([k,v]) => typeof v !== 'object' || (v.xss===0 && v.imgs===0));
  console.log(pass ? 'PASSED — t32 no hostile text runs on any screen' : 'FAILED — t32');
  process.exit(pass?0:1);
})();
