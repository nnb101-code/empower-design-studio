// (audit A3) test mode, no printer: the animal is marked only when the virtual stickers are on the screen; a second tap waits
const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs'); const { execSync } = require('child_process');
const APP = '/home/user/empower-design-studio/glatttrack/kosher-app-v10.38.html';
const db = q => { fs.writeFileSync(__dirname + '/q.sql', q); return execSync(`psql -h /tmp -p 5433 -U postgres -d gtapp -qAt -f ${__dirname}/q.sql`).toString().trim(); };
(async () => {
  db(`update settings_pilot set settings = (settings - 'printers') || jsonb_build_object('screenDevices', '{}'::jsonb) where id=1;`);
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const ctx = await b.newContext({ viewport:{width:800,height:900} });
  await ctx.addInitScript(()=>{ if(localStorage.getItem('i')) return; localStorage.setItem('i','1'); window._gtLicShown=true;
    localStorage.setItem('ks_device_token','tok-stamps-live-0000000000000001'); localStorage.setItem('ks_kiosk_role','stamps'); localStorage.setItem('ks_kiosk_index','0'); localStorage.setItem('ks_device_id','e2e_stamps_001'); });
  await ctx.route(u=>new URL(u).pathname==='/', r=>r.fulfill({status:200,contentType:'text/html; charset=utf-8',body:fs.readFileSync(APP)}));
  const p = await ctx.newPage(); p.on('dialog', d=>d.accept()); p.on('pageerror', e=>console.log('pageerror', e.message));
  await p.goto('http://localhost:8083/'); await p.waitForTimeout(7000);
  const res = await p.evaluate(async()=>{ const out={};
    try{ mgrRenderPrintPreview(); }catch(e){ out.err=String(e); }
    const t=document.getElementById('printPartsCountTxt'), i=document.getElementById('printPartsCount');
    out.txt=t&&t.style.display!=='none'?t.textContent:null; out.inputShown=i&&i.style.display!=='none'; out.hasProducts=_gtHasProducts();
    const st=KS.getSettings(); const keep=st.printShowQR; st.printShowQR=false;
    out.kosherQR=_gtStickerData(2,'kosher',false,null).opt.showQR; out.legsQR=_gtStickerData(2,'legs',false,null).opt.showQR; st.printShowQR=keep;
    const rows='<tr><td>=1+2</td><td>-5</td><td>@x</td><td>ok</td></tr>'; const tb=document.createElement('table'); tb.innerHTML=rows;
    let blob=null; const U=URL.createObjectURL; URL.createObjectURL=b=>{ blob=b; return 'blob:x'; };
    try{ gtExportTable(tb,'t'); }catch(e){ out.expErr=String(e); } URL.createObjectURL=U; out.csv=blob?(await blob.text()).replace('\ufeff',''):null;
    return out; });
  console.log(JSON.stringify(res));
  const pass=!res.err && (res.hasProducts ? (res.txt && !res.inputShown) : res.inputShown) && res.kosherQR===true && res.legsQR===false && res.csv==="'=1+2,-5,'@x,ok";
  console.log(pass?'PASSED — A-L2/L3/L4':'FAILED');
  await b.close(); process.exit(pass?0:1);
})();
