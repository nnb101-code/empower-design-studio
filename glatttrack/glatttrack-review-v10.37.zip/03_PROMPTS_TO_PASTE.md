# Prompts to paste (one per message)

Use the strongest model with the longest thinking available (for example ChatGPT with GPT-5.6 Sol and "Thinking", or Claude with extended thinking).

The client file is large. If the chat cannot take it whole, attach only `server-functions.sql` for the server topics.

## First message
Attach: `01_PROJECT_CONTEXT.md`, `02_REVIEW_INSTRUCTIONS.md`, `server-functions.sql`, `gt-server-fix-v10.37.sql`, `kosher-app-v10.37.html`

```
Read 01_PROJECT_CONTEXT.md and 02_REVIEW_INSTRUCTIONS.md fully. Do not review yet. Reply only with:
(1) the main server functions and client modules you found, with line ranges,
(2) any rule in the context file you cannot find enforced on the server.
```

## Then one topic per message
1. Review only the animal lifecycle on the server: `claim_animal_stage`, `animal_push` and the trigger functions `_animals_merge`, `_animals_stage_guard`, `animals_pilot_guard_corrections`, `_stage_order_error`. Can any path skip a stage, rule twice, or overwrite a final ruling?
2. Review only corrections: `eso_change`, `_correction_check`, the correction paths in `animal_push` and the triggers, and the client `_gtCorrectionBlock`. Is the rule in the context file enforced the same way on every path?
3. Review only USDA HOLD and "?": `hold_set`, `hold_resolve`, `_hold_block`, `_hold_caller_error`, `board_flags`, and the client gating (`gtHeldAt`, parts / stamps / legs and their reprints).
4. Review only auth and sessions: `manager_login`, `worker_login`, `_session_role`, `_manager_session_valid`, `_stage_allowed`, `_device_write_allowed`, `_current_worker`, `_derive_actor`, pairing (`device_request_pairing`, `device_pair`, `device_pairing_status`), `support_access_set`, and every SECURITY DEFINER function's first checks.
5. Review only the manufacturer: everything a manufacturer session can call or write (`push_settings` maker_keys, `event_append`, `support_*`, `manufacturer_set_billing`, `device_manage`). Can it touch kashrut data in any way?
6. Review only sync and replay: the client outbox (`_syncPump`, `_pushBatch`, `_claimNow`, `_esoNow`, `_pushAnswer`) against `_cmd_get` / `_cmd_put` and every error code the server returns. Is every code handled, and is anything retried forever or dropped silently?
7. Review only the daily reset and the epoch: `reset_daily_board`, `request_daily_rollover`, `_do_board_reset`, `_board_unfinished`, `_board_write_lock`, `stale_board` handling on both sides.
8. Review only `push_settings`, `_settings_value_error` and the client `updateSettings` callers.
9. Review only the event ledger: `event_append`, `_events_chain_link`, `verify_event_chain`, and the client `_sbRecordEvent`.
10. Review only `gt-server-fix-v10.37.sql`. Is each change correct and complete, and could it break anything?

## If the answer stops early
```
continue from exactly where you stopped
```
