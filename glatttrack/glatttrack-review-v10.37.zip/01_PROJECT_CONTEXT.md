# Project Context — GlattTrack v10.37

Read this file fully before reviewing any code. It defines what the system is supposed to do. Anything in the code that contradicts these rules is a bug, even if the code "works".

## The files
- `kosher-app-v10.37.html`: the client. One HTML file (~17,800 lines) that runs on every tablet, in an Android WebView or a desktop browser.
- `server-functions.sql`: all server functions of the `public` schema, exported from Supabase as they run today, about 217 functions. The same SQL also runs on each plant's on-site server. Tables, RLS policies and triggers definitions are not included; trigger *functions* are, for example `_animals_merge`, `_animals_stage_guard` and `animals_pilot_guard_corrections`.
- `gt-server-fix-v10.37.sql`: three server fixes not yet applied, to `_animals_merge`, `reset_daily_board` and `manager_login`. Review it too.

## What the system is
- A kosher slaughter inspection ERP for slaughter plants (international market, USDA plants in the US).
- Client store `KS` (an IIFE): animals of today's board (ids 0..999), settings, meta.
- Writes from tablets go through a localStorage outbox. One ordered sync pump (`_syncPump`) sends them with command ids (`p_command_id`). The server answers a repeated command from `processed_commands` (`_cmd_get` / `_cmd_put`).
- Main RPCs:
  - `claim_animal_stage`: first ruling of a stage, atomic.
  - `animal_push`: batch upsert. The trigger functions `_animals_merge`, `_animals_stage_guard` and `animals_pilot_guard_corrections` decide what is accepted.
  - `eso_change`: esophagus correction.
  - `set_not_chalak_outer`: sends an animal to the rabbinate outer screen.
  - `hold_set` / `hold_resolve`: USDA HOLD and "?" questions.
  - `push_settings`: settings. Stations may write only station keys. List keys are merged server-side.
  - `event_append`: hash-chained event ledger. A station may write only its own stage.
  - `reset_daily_board` / `request_daily_rollover` / `_do_board_reset`: daily board with `board_epoch`.
  - `processing_board` / `carry_push`: legacy multi-day processing.
- Auth:
  - Device pairing: `device_request_pairing`, then `device_pair` by the team leader, then `device_pairing_status`. The device gets a token and sends the `x-device-token` header.
  - Team leader / owner / manufacturer sessions: `manager_login`, `x-manager-token`.
  - Worker code sessions: `worker_login`, `x-worker-token`.
  - Manufacturer access opens only when the team leader opens support access (`support_access_set`).

## Roles and stations
- Stations: slaughter → esophagus → legs/head (can be split into two screens) → inner → outer (A/B; "not chalak" animals go to the rabbinate outer screen) → parts → stamps (with stage-1 weighing).
- View-only supervisor screens: cooler, nikur, salting, shipping. There is also a counter display.
- People:
  - Shochet and inspectors.
  - Team leader (manager).
  - Owner (view only).
  - Manufacturer (vendor/support).

## Business rules (must be enforced, on the server first)
1. **Ruling authority**
   - The team leader NEVER rules on animals (test mode aside).
   - Each station rules only on its own stage. The outer inspector's ruling is final.
2. **Corrections (current owner decision, v10.32 to v10.37)**
   - A station (any tablet of that station) may change its ruling until the number reached the next station:
     - slaughter: until the esophagus checked it.
     - esophagus: until the legs/head stickers were printed.
     - inner: until the outer ruled.
   - The outer ruling may still be changed after parts stickers / stamps (decided for now; may change later).
   - Every change is recorded and shown to the team leader.
3. **USDA HOLD / "?"**
   - A held or condemned animal must not be printed, stamped or sorted.
   - Only the station that marked a hold resolves it.
4. **The manufacturer**
   - Has near-full remote access (support, diagnostics, technical settings).
   - Must NEVER record or change kashrut records.
   - Is the only one who sets billing by weight.
5. **Devices**
   - Each tablet is locked to one screen, assigned only by the team leader remotely, never by entering a code on the device.
   - License per plant, capped by device count.
6. **Continuity**
   - Work must survive internet / server outages: the outbox keeps it and replays it in order, without duplicates.
   - Work that cannot reach its day any more must be recorded, never silently dropped.
7. **Daily reset**
   - An animal does not leave the board without all its kashrut marks.
   - An emergency reset needs a written reason and is audited.

## Conventions
- Full he / en / es on every screen (`L(he,en,es)`, `AT_DICT`, `I18N_DOM`). Hebrew is the default, RTL.
- Simple `onclick` handlers (WebView). No vibration.

## Already reviewed and fixed in v10.37 (check for regressions, do not re-report)
- Settings saves sent the whole settings object.
- Esophagus double change lost the shochet's nevela (client).
- A reopened inner treif that was cancelled came back as kosher.
- Held animals could be printed / stamped offline or by reprint.
- Unsent rulings of an ended day were dropped without a record.
- The ledger and the backup failed on a plain-http plant server.
- The archive was dated by the reset time.
- GS1 / pound scale labels were misread.
- A QR with a long payload was missing.
- CSS class clashes.
