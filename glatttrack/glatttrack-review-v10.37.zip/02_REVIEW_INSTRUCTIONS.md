# Code Review Instructions

You are a senior engineer doing a deep, line-level review of a production system that runs in real slaughter plants. Correctness matters more than speed.

## Inputs
1. `01_PROJECT_CONTEXT.md`: the rules. Read it first.
2. `kosher-app-v10.37.html` (client), `server-functions.sql` (server), and `gt-server-fix-v10.37.sql` (pending server fixes). Review only the part named in the current request.

## Method
- Go function by function. For each one, ask:
  - What does it receive?
  - What does it change (rows, settings, localStorage, DOM)?
  - Who may call it?
  - What can go wrong?
- For every client call to the server, read BOTH sides: the client code that calls the RPC and the SQL function it reaches. Many rules are enforced only on the server. A client-only check is not protection.
- Trace an animal through every station and every state transition, including corrections, holds, offline replay, and the daily reset.
- Check every rule in the context file against the code, on the server first.

## What to look for
1. **Logic bugs**: wrong conditions or wrong transitions; records that get stuck; wrong values written.
2. **Rule violations**: any path where a role can rule, correct, release a hold, change billing, or reach kashrut data that it may not. This includes paths through `animal_push` and the trigger functions, not only the dedicated RPCs.
3. **Data integrity**:
   - outbox ordering;
   - command-id replay;
   - stale writes;
   - races between devices (locks, `for update`);
   - board epoch / reset races;
   - lost or duplicated records.
4. **Security**:
   - SECURITY DEFINER functions callable without the right session / device;
   - injection through dynamic SQL (`format` / `execute`);
   - token handling;
   - rate limits;
   - innerHTML without escaping.
5. **Edge cases**: first or last animal (ids 0 and 999); refresh mid-workflow; device reassigned mid-shift; offline then online; two devices at the same moment.
6. **i18n**: user-visible text missing in he / en / es.
7. **Dead code and drift**: client and server disagreeing on names, values, or limits.

## Output format (strict)
For every finding:

```
### [#] Title
- Severity: Critical / High / Medium / Low
- Location: file + function + line number(s)
- Code: (exact quote of the problematic lines)
- Problem: what goes wrong and in what concrete scenario
- Fix: the minimal concrete change (code)
```

Order by severity, Critical first.

## Rules
- Report only problems you can point to in the code, with an exact quote. If unsure, mark it "Needs verification" and say what to check.
- Before reporting, search both files for code that already handles the case (escaping, try/catch, a server-side check, a trigger). A finding that is already handled elsewhere is wrong.
- No rewrites, no new architecture, no summary, no praise, no roadmap.
- If you cannot finish, say exactly where you stopped.
- Write explanations in Hebrew; keep code and identifiers as they are.
