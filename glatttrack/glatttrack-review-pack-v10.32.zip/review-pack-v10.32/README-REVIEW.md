# GlattTrack — review pack (app v10.32, server schema step 46)

This pack is the CURRENT state. Review these files only.

## Files

| File | What it is |
|---|---|
| `active-schema-snapshot.sql` | **Audit this first.** `pg_dump --schema-only` (public + gt_rls) of a clean database built from `glatttrack-schema-full.sql`. Exactly one ACTIVE definition of each function, trigger, RLS policy and grant. |
| `setup-supabase-step46-order-and-processing-days.sql` | The new migration (run after step 45). |
| `STEP46-CHANGES.md` | What step 46 / app v10.6 changed (Hebrew). |
| `security-selftest.sql` + `security-selftest-result.txt` | Release gate: **141 / 141**. One statement (one DO block) whose changes are all undone inside it (see v10.15 below). |
| `SECURITY-MANIFEST.md` | Permission map (step 45 observed table) + a step-46 section. |
| `active-security-manifest.sql` + `-result.txt` | Prints the active security surface. |
| `kosher-app-v10.32.html` | The app (UI, offline store, sync client). `GT_MIN_SCHEMA = 46`. |
| `setup-supabase-step44/45/46-*.sql` | The last three migrations. |
| `glatttrack-schema-full.sql` | Full install script (base + steps 1–46, history included; last definition wins). |
| `test-mode-on.sql` / `test-mode-off.sql` | The owner's SQL-only test switch. |
| `plant-server/` | Plant resilience kit (bash, runs as root on the plant servers, NOT in the database): standby server, floating address, UPS, nightly checked backup. Guide: `PLANT-RESILIENCE-HE.md`. |

## Fixed in v10.32 (server 02 + app) — after the v10.31 review

- **A1 — "?" / USDA through the worker login.** `hold_set` and `hold_resolve` now call `_hold_caller_error(p_station)`: a paired tablet of that station, and on a screen whose workers log in with a code (`loginModeByRole` = code / both) only with a live worker session (`_worker_gate`; the refusal is returned as `{"ok":false,"error":"worker_login_required"}`, nothing is written). The app shows "log in with your code, then tap again" and opens the screen's login.
- **F1 — one shared inner + outer screen.** `_hold_caller_error` lets its inner tablet put / close an `outer` hold when `_gt_one_inspection()` (the same rule as `_stage_allowed('outer')`), after its worker's login; any other configuration → `wrong_station`.
- **A2 — a held part is not printed, on the server too.** The existing columns now mean: `tongue_sticker` = the tongue sticker is out, `cheek_sticker` = both cheek stickers are out, `parts_print_count` = how many stickers are out. `_parts_print_block()` (used by the `b_animals_hold_guard` trigger and by `carry_push` for an older processing day) refuses: the tongue flag while the tongue is on USDA hold (open or condemned); the cheeks flag while a cheek is; and the count reaching 3 while any small part is. The app (`_partsRecordPrinted`) sends the real count and flags: tongue held → count 2 + cheeks; after the release → count 3 + tongue. A held part is also left out of a reprint. Known limit (no new columns): with one cheek held, the server knows "cheeks not both out" and which cheek is held (the hold row), not a per-cheek printed flag.
- Running 02 while tablets work: in the Supabase SQL Editor the file is one transaction and could deadlock with a tablet's request (reported: `40P01 deadlock detected`, nothing changed). 02 now starts by locking the busy tables together (`lock table … in access exclusive mode`, `lock_timeout` 30 s), so it waits for running requests and then goes on alone. Checked: 02 run 5 times as one transaction while 3 tablets polled the server — no deadlock.
- Self-test fix: on a plant whose own kashrut status is carried by an animal on the board, the two `push_settings` value-shape checks replaced the status list and got `status_in_use` (correct server answer) instead of the expected result — reported 139 / 141 on Supabase. The checks now keep the plant's own statuses in the list. Reproduced locally with a custom status in use (139 / 141) → fixed (141 / 141 with and without one).
- Self-test **141 / 141**: 3 new checks (worker login for "?" / USDA put and close; shared screen outer "?"; held part not printed + released part recorded). The old check that pushed the full set while the tongue was held now pushes the two cheeks only. The 3 new checks FAIL on the v10.31 server (138 / 141) and pass on v10.32. Fresh install (`glatttrack-schema-full.sql`, rebuilt with the current step 46) + a second run of 02: 141 / 141.
- Browser: `browser-tests/hold-worker-login-part-print.test.js` — tongue on USDA → print shows "cheek 1 + cheek 2", server `2 / tongue=false / cheeks=true`; tapping the number again → reprint window (not a second set); release → "printed now: tongue", server `3 / true / true`; the parts screen switched to code login → USDA refused, the login screen opens, nothing written.

## Changed in v10.31 (app only)

- A number on "?" (`.num-cell.gt-q` / `.gt-qb`) blinks all the time on every screen (opacity + glow keyframe `gtQBlink`; opacity is used because the cell's background is `!important`).
- Inner check: "?" in any window (rumen / maw / lung) now closes the number at once with "?" (`gtInnerQuestion` → `_gtInnerWait`): every window closes, the number is not left as a float, the server hold (`hold_set`, station inner, kind question) is put. It no longer goes on to the next window (this reverses v10.29). Tapping the number later (`gtInnerResume`) opens the window that is "?" first. The v10.29 auto-open of the lungs in `mawDone` (`_qchain`) was removed.
- The rabbinate screen (outer instance 1, role `kosher`, with 2 outer screens and "not chalak" on) has "? Question" on its top bar and "?" in its decision window, like every screen (same `scOuter` code; checked in the browser).
- The slaughter screen no longer has the USDA HOLD button (`gtTopBarsInit` skips it for `slaughter`). The shochet's round "?" stays.
- No server change: steps 02 / 03 are the same as v10.30 (138 / 138).
- Browser test: `browser-tests/question-blink-inner-close-rabbinate.test.js`.

## Changed in v10.30 (app only)

- Language switch: `applyLang` now redraws the team leader's open tab (it was only redrawn when the tab was opened again), the clock line, and the status rows (health, processing day, test mode, holds cards); ~60 Hebrew-only texts got English / Spanish (`I18N_DOM`, plus `I18N_PARTS` for texts that hold a name). Audits in `browser-tests/language-*.test.js`: no Hebrew left right after the switch except kashrut status names (never translated by design) and people's names; the switch takes < 50 ms.

## Changed in v10.29 (app only)

- Inner "?" marks only that window's item (rumen / maw / lungs), at once, and the check goes on to the next window of the same animal. At the end (lungs) an open item keeps the animal waiting (not approved for outer, server hold stays open); the open items are kept on the tablet that holds the lung check (`gt_inner_qsteps`). Tapping the number opens the first open item; decided items are skipped; the drawing is kept. Test `browser-tests/inner-question-per-window.test.js`.

## Changed in v10.28 (app only)

- Inner: the "?" button is in each window of the check (rumen, maw, lungs) instead of the top bar. The animal keeps its in-progress claim and what was done (rumen, maw, lung drawing); tapping the "?" number resumes at the same window (`gtInnerResume`). Esophagus and outer: "?" also inside the decision window. Test `browser-tests/inner-question-windows.test.js` + `v1028-*.png`.

## Changed in v10.27 (app only)

- The team leader's home tab shows a card to switch test mode (every station on one device) on / off and to go to the stations; before it was only in Settings → System. The server flag and its 8-hour limit are unchanged. Screenshot `browser-tests/v1027-test-mode-home-card.png`.

## Changed in v10.26 (server 02 + app) — "?" question, USDA hold, changes always possible

Please review this part first; it relaxes the old correction rule on purpose (the plant asked for it).

**Server (§27–§29 at the end of the step-46 file):**
- `animal_holds` (RLS on, no grants) + `hold_set(p_id, p_station, p_kind, p_part, p_board, p_command_id)` / `hold_resolve(p_hold, p_resolution, p_command_id)` / `board_flags(p_token)`; caller = a paired tablet of that station only (`_hold_station_of_role(_caller_device_role())`).
  - kind `question` ("?"): the station's own open question. Ruling stations (slaughter / eso / inner / outer): closed by the station's own ruling (`zzzzz_close_questions` AFTER trigger), or `cancelled`. Processing stations: `answered` / `cancelled`.
  - The shochet's open "?" (slaughter null): `_stage_order_error` lets the esophagus rule it and legs / head stickers print; inner / outer still `not_slaughtered`. An esophagus nevela closes it (`note='eso_nevela'`); `eso_change` back to ok re-opens it and puts `slaughter` back to null (one row written with `gt.reset_in_progress` so the merge trigger, which never clears a ruling, lets it through).
  - kind `usda`, part whole / right / left / cheek1 / cheek2 / tongue. Whole (open or condemned) stops every station (`_hold_block` in the new BEFORE trigger `b_animals_hold_guard`, in `claim_animal_stage`, `carry_push`, `carry_claim`); a half stops only that weight; a part stops nothing on the server (the app prints the other parts and prints the held part on release). `released` / `condemned` only by the station that put it.
  - Processing: `_proc_pending` skips held / condemned numbers (a held number does not keep a station on an older day); `_proc_finalize` keeps a board while any hold on it is open; `_do_board_reset` carries a board with an open hold and closes (`board_closed`) holds of a board it does not keep; `processing_day_close` closes that station's holds; `_board_unfinished` counts an open slaughter "?" (the rollover waits).
- Corrections: `_correction_check` now allows any tablet whose role is the stage's station (or the device that ruled), at any time — no `moved_on`, no "later stage started". Unchanged: ESO_LOCKED (slaughter change after an esophagus nevela), the brake on refused corrections, the time-only rule, test-mode manager without a role → `correction_not_allowed`.
- `animal_changes` + `change_ack(p_token, p_id)` (team leader): a change made after a later station acted is recorded with what was already done (`_gt_done_after`), written from `animals_pilot_guard_corrections` / `eso_change`.
- Self-test: 138 checks. The old "refused after moved on / another tablet / later stage / after print" checks were rewritten to the new rule (allowed, recorded, handled); 5 new checks for holds. Fresh install + a second run of 02: OK.

**App:** top-bar buttons "? שאלה" / "USDA HOLD" / "מעוכבים · N" on every station (slaughter: a round "?" button); numbers show "?" (yellow), USDA (purple), "⚠ השתנה" (red frame); every station's next / no-skip computation skips held numbers and its own open "?"; the change dialogs no longer block — they show what was already done. Team leader: "פתוחים עכשיו" card with "טופל". Browser tests: `browser-tests/holds-*.test.js` + `holds.result.txt` + `v1026-*.png`.

Questions for the reviewer: is anything in the relaxed correction rule exploitable (a tablet of another station, a retired / unpaired key, the team leader)? Can a hold be bypassed through any write path (animal_push, the offline esophagus upsert, carry_push, eso_change)? Can a board with an open hold be lost?

## Changed in v10.25 (app only)

- Settings → Kashrut → statuses: a fixed row "רבנות כשר · Rabbinate Kosher" (colour override `statusColorOverrides.kosherRab`, mark `customSeals.kosherRab`) next to "רבנות חלק"; no on/off or remove (it is the rabbinate screen's kosher ruling, stored as `kosher` on a not-chalak animal). The marks card always has its tile. Screenshot `browser-tests/v1025-kashrut-statuses.png`.

## Changed in v10.24 (app only)

- A kashrut mark picture may hold several marks (the plant: Beit Yosef = 4 marks, MK = 2). Upload keeps up to 700 px on the long side (white background), shrinking only while the data URL is over ~390 KB (server limit 400000); last resort a 200 px JPEG. On the kosher sticker the mark is its own full-width row under the number and QR. Test `browser-tests/kashrut-marks-several.test.js` + `v1024-stickers-several-marks.png`.

## Fixed in v10.23 (server 02)

- `_gt_standbys()` counted logical walsenders (Supabase Realtime) as streaming standbys, so on the cloud server `standby_down` was never raised and the self-test check "standby server and UPS" failed. Now walsenders holding a logical slot are excluded. Reproduced locally with `pg_recvlogical` (134/135) → fixed (135/135).

## Fixed in v10.23 (app)

- v10.22 could ERASE the team leader's kashrut marks: a paired team-leader device opened before login (device key, no session) pulled `seals_get` from a server that never had marks (version 0) and replaced its local marks with the empty set. Now an empty server set with version 0 never replaces local marks; a team-leader session uploads them. Test `browser-tests/kashrut-marks-not-erased.test.js` (+ result: v10.22 erased, v10.23 keeps). The marks card (`#sealUploadGrid`) now exists in Settings → Kashrut (it was rendered into a missing element before).

## Changed in v10.22 (server §26 + app)

- **Kashrut marks were never shared.** The team leader's seal picture per status (`settings.customSeals`) was kept in the team-leader device's localStorage only (`_sbPushSettings` skips `customSeals`), so the parts / stamps tablets printed kosher stickers WITHOUT the kashrut mark. Now: table `kashrut_seals` (RLS on, no grants; key = a status key, image = data URL), `seal_set(p_token, p_key, p_image)` (real team leader only; png / jpeg / webp data URL ≤ 400 000 chars; empty = remove; bumps `plant_state.sealsVersion`; `_security_event`), `seals_get(p_token, p_version)` (a paired device or team leader / owner; returns `{same:true}` when the version did not change). App: every change to `customSeals` on a team-leader session is sent; every device pulls at start, every 20 s and before the health check; a team leader whose marks existed only locally uploads them once.
- A kosher sticker with no mark prints a red dashed "חסר סימן כשרות / No kashrut mark"; the health card shows "Kashrut marks for the stickers" red with the missing statuses.
- Self-test: + "kashrut seals" (team leader sets; a tablet reads; a tablet can't set; bad picture / bad key refused; no device refused; same version → `same`) → **135 / 135** on a fresh database. Manifest: `seal_set`, `seals_get` added to the expected grants. Browser: `browser-tests/kashrut-marks-sync.test.js` (+ result).

Please check: size / abuse of `seal_set` (one TL, 400 KB per status), and whether `seals_get` should be narrower (it returns the pictures to any paired tablet — they are printed on public stickers anyway).

## Changed in v10.21 (app only)

- First installation: one on-screen form (team leader name, personal code, server setup code) instead of three `prompt()` windows; `create_first_manager` is always called WITH the setup code; a wrong code keeps the form open ("wrong setup code"); success → "the server approved the installation" → login + self-registration as the first team-leader device (with the v10.20 wait). Test `browser-tests/first-install-form.test.js` (+ result, `v1021-first-install-form.png`).

## Fixed in v10.20 (app only)

- **First installation: the first team leader could be logged out at once.** `_gtSelfPairLeader` registers the device as the plant's team-leader device (`device_pair`, role leader) and only then receives the device key (`device_pairing_status`). A `system_health` call in that window (no device key yet, but the plant already has a team-leader device) is refused `unauthorized`; `_gtSessionGone` confirmed with `manager_session_check` (also refused in that window) and logged the team leader out — the installation stopped. Now `_gtSelfPairLeader` publishes its promise (`window._gtSelfPairing`); `_gtSessionGone` waits for it and then checks; health is refreshed after the registration. Test `browser-tests/first-install-race.test.js` forces the window (the `device_pair` answer is held 5 s while health is asked): v10.19 logged out, v10.20 stays and opens the installation page (`first-install-race.result.txt`). Please check for other calls in that window that could act on an `unauthorized`.
- **A sticker printed from a tablet whose screen language is English** had its Hebrew words translated by the DOM translator ("נבלה / Nevela" → "Nevela / Nevela"). The sticker element is now `data-no-i18n`. `v1020-sticker-samples.png`.

## Changed in v10.19 (app only)

Owner's decision on legs / head stickers: **printed on the sticker** — the number, Hebrew date, Gregorian date and the slaughter time; the status only when the animal is nevela / shot or "לא חלק" (Hebrew + English). **In the QR** — everything: `BH|N:<n>|D:<date>|HD:<Hebrew date>|W:<weekday he / en>|TM:<HH:MM>|SH:<shochet>|S:<status at printing>` (the ISO time copy was dropped to keep the code small). Scanners still read only `N:` and show the current ruling. Kosher stickers unchanged. Test: `browser-tests/legs-sticker-v1019.test.js` (+ result, `v1019-legs-stickers.png`).

## Changed in v10.18 (app only; the server is the same — one comment changed in the step-46 file)

Owner's decisions:
- The marking is called **"לא חלק"** (not "לא חלק"), English "Non-Chalak", everywhere in the app.
- **Legs / head stickers are printed before the ruling** and carry: the number, weekday + Hebrew date, Gregorian date, the **shochet** and the slaughter time, and a QR with `BH|N:<number>|D:<slaughter date>|SH:<shochet>|T:<slaughter time ISO>|S:<status at printing>` (the dates are the slaughter day, also on a reprint on a later day). **After the ruling the number "updates":** every scanner reads the number (`_gtCodeNum`: the `N:` field of the app's own code, else the first number) and shows the animal's CURRENT ruling from the board — never the `S:` printed on the sticker.
- Browser: `browser-tests/legs-sticker-before-ruling.test.js` (+ result, `v1018-*.png`): "לא חלק" button; a legs sticker printed right after slaughter; the outer inspector rules glatt; the legs sort scans the PRINTED code → "#1 גלאט". All stations re-run (slaughter → esophagus → inner → outer → legs + sort → parts → stamps + weight): same results as v10.17.

Please check: can `S:` (status at printing) be used anywhere as if it were the ruling; is the `N:` parsing safe against a shochet name with `|N:` in it (the name's `|` is replaced by `/` in the code).

## Changed in v10.17 (owner's decisions; same step 46 — new §25 + the "not chalak" check in claim_animal_stage)

Owner's decisions:
1. **A kashrut status is shown exactly as it was written, in every language.** "MK" stays "MK" in the Hebrew screens; "גלאט" stays "גלאט" in the English and Spanish screens. App: `statusDisplayName()` returns the written name (built-in: the Hebrew name; custom: the name the team leader typed). Every place that translated a status word (grids, decision buttons, summary bars, summaries / rankings / worker tables, animal card, T dictionaries, the DOM translator `I18N_DOM`) now uses the written name. Prose sentences are still translated (the status inside them is quoted as written). "לא חלק" (a marking at slaughter / maw, not a ruling) and nevela / shot (slaughter results) are still translated.
2. **Statuses can be added and removed** (Settings → Kashrut → statuses). Added: one name for every screen + an English name for the stickers. Removed statuses (built-in or custom) are listed with "↩" and can be brought back (`mgrRestoreStatus`). טרף can't be removed (as before).
3. **"Send to the rabbinate" is routing, not a status.** Rabbinate statuses are **רבנות חלק** (`rabChalak`, renamed from "חלק רבנות") and **רבנות כשר** (kosher on a "not chalak" animal, renamed from "כשר רבנות"). With two outer screens and the rabbinate option on, the second outer screen IS the rabbinate screen ("בודק חוץ — רבנות"). The glatt screen's decision window shows the glatt statuses and, under a separator, "↪ שליחה למסך רבנות" (an outlined action button, not a ruling button); רבנות חלק is not offered on the glatt screen. The rabbinate screen offers רבנות כשר / רבנות חלק / טרף for an animal that was only **sent** there, and רבנות כשר / טרף only for an animal marked "לא חלק" by the shochet or at the maw check (unchanged rule). The outer summary bar is built from the screen's own statuses, by their written names.
4. **Stickers print the status in Hebrew AND English together** (e.g. "גלאט / Glatt", "רבנות כשר / Rabbinate Kosher", "נשחט / Slaughtered"; MK once). `renderSticker()` — the same renderer the printer path and the preview use.

Server (§25 + an in-place change in `claim_animal_stage` and `_kosher_ready`; step 46 file re-run):
- `_nc_fixed(a)` — "not chalak" from the shochet (`slaughter = 'notChalak'`) or the maw (`not_chalak_inner`). `_nc_outer_value_ok(a, v)` — an outer value allowed for this animal: not "not chalak" → anything (as before); else `kosher` / `treif`; and `rabChalak` only when the animal was just sent (`not_chalak_outer`) and not `_nc_fixed`. Both internal (SQL, not SECURITY DEFINER, no grants to anon / authenticated / public — see the manifest result).
- Used on every write path: `claim_animal_stage` (first ruling → `bad_value / nc_kosher_or_treif_only` as before), the trigger `_animals_nc_outer_value` (any push / correction → `GT:INVALID_VALUE`), and `_kosher_ready` (so a sent animal ruled רבנות חלק gets its parts stickers / stamps).
- Self-test: + "rabbinate screen: a sent animal may be ruled רבנות חלק (and is kosher-ready); a shochet / maw 'not chalak' may not" (+ a push changing it to glatt refused) → **134 / 134** (fresh database from `glatttrack-schema-full.sql`, and on a copy as a non-superuser). Step-46 self-check line for the rule.
- Browser: `browser-tests/rabbinate-screen-and-status-names.test.js` (+ result, `v1017-*.png`): glatt screen buttons; send → server `not_chalak_outer`; rabbinate screen (English UI) shows Hebrew names, rules רבנות חלק → server `rabChalak`; a shochet-NC animal gets only רבנות כשר / טרף; the glatt screen's grid and summary in English show גלאט / MK. `status-settings-and-stickers.test.js`: remove MK → "↩ MK" → back; add a status with an English name; stickers for every status.

Please check: (a) can a sent animal be made `rabChalak` through any path other than claim / push (e.g. carry_push for a processing day — the trigger covers the live board; animals_carry has no outer_status); (b) is it right that a correction from רבנות חלק back to glatt is refused once the animal was sent (it is: `not_chalak_outer` can't be cleared); (c) anything in the app that still shows a translated status word.

## Fixed after the v10.15 review (app v10.16; same step 46 — new §23 + changes in §20/§21; plant-server kit)

Every A-finding was confirmed first, then fixed, then tested (browser tests are in `browser-tests/`).

| # | Finding | Confirmed? | Fix | Test |
|---|---|---|---|---|
| A1 | worker login mode not enforced on ruling RPCs | **Yes** — a device key alone could rule on a "code" screen | `_worker_gate(role)` (internal) called from `_stage_allowed()` and `_nc_outer_allowed()`: on a screen with `loginModeByRole` = `code` / `both`, a write needs a live worker session of THAT screen's list on THAT device (`_current_worker()`), else `raise 'GT:WORKER_LOGIN_REQUIRED'` (SQLSTATE `GTW01`). Covers claim_animal_stage, animal_push (trigger), carry_push / carry_claim, eso_change, outer_open, lung_drawing_set, set_not_chalak_outer. 1both: the device is `inner`, its one list is checked. `_cmd_put` never stores a `worker_login_required` answer, so the same command after the login goes through. A **name-only** screen has no secret — not gated (the name is recorded, unknown names get "(?)"). App: such a refusal keeps the change on the tablet, sends the worker to the login, and the change goes out after the login; no "local-only" logins any more (old-format codes must be reset by the team leader). | self-test: 2 new checks (no session / another tablet's session refused; every write path refused; same command after login OK) + shared-screen check updated · browser: `worker-login-gate` |
| A2 | `leader_device_replace` not atomic | **Yes** — reproduced with two real connections: both succeeded | `pg_advisory_xact_lock(hashtext('glatttrack_leader_device_replace'))` first; the second request waits, then finds no recovery code (`no_recovery_code`) | `recovery-race` (two connections, before / after) + step-46 self-check line |
| A3 | split brain on an A↔B cut | **Yes** (by design of promote.sh) | No automatic promotion any more (`GT_AUTO_PROMOTE=0`): a person confirms the main server is OFF and runs `takeover.sh`. The floating address is held ONLY by a server that is not in recovery and not fenced (`check_pg.sh`), so a standby never holds it. Automatic failover would need a third "witness" device — not in the kit. | `plant-server-ha` scenarios 2, 5, 6, 7 |
| A4 | "no ruling lost" not true after the standby is gone | **Yes** — the wording was too strong | A plant decision in `gt-plant.conf`: `GT_SYNC_MODE=available` (default, work goes on; rulings made while the standby is down live on one server) or `strict` (a ruling is confirmed only when both servers have it; work waits). The guide states the risk plainly. | scenarios 3 (strict) and 4 (available) |
| A5 | backup "verified" even when pg_restore failed | **Yes** (`|| true`) | `pg_restore --exit-on-error` must succeed; the restored copy must have the live schema step, at least the events that existed when the backup began, and `verify_event_chain()` ok — else `lastBackupFailedAt` + reason | scenarios 9, 10 (broken chain → failed), 11 (restore fails part-way → failed) |
| A6 | known default replication password | **Yes** | `GT_REPL_PASS` and `GT_VRRP_PASS` empty in the sample; the tools refuse empty / sample / short (<16) passwords; the settings file is chmod 600, umask 077; keepalived settings are generated from it (`make-keepalived.sh`), no shared secret in the kit | scenario 0 |
| A7 | cloud fallback can bypass "plant server only" | **Partly** — the cloud URL is the owner's TEST project, but a plant tablet could fall back to it if gt-config.js failed to load | A tablet that ever ran with a plant `gt-config.js` is bound (`gt_plant_bound`); without the file it never uses the cloud — it stops, and the stop screen says why. Test copies (never bound) keep the cloud test server. | `offline-hint-and-plant-binding`, `plant-config-missing` |
| B2 | event_append too flexible | Yes | from the API: the server's own stages (`security`, `admin`, `audit`, `support`, `system`, `device`, `manufacturer`, `leader`) → `reserved_stage`; a station tablet only its station's stages + `correction` (stamps: + `weight`; shared screen inner: + `outer`); the team-leader device: `settings`; test mode unchanged | self-test: 1 new check |
| B4 | `navigator.onLine` on a LAN without internet | Partly (Chrome usually reports online on a LAN) | the browser's "offline" is only a hint: the server is always asked; the screen stops only when the server is silent for 15 s | `offline-hint-and-plant-binding` (onLine=false, server answers → never locked) + the 15-s black-hole test still locks |
| B6 | keepalived secret in the kit | Yes | see A6 | — |

Also new in v10.16 (app only, read-only — no new server path): Summaries tab — weight per farm / type / farm × type / inspector, a "same farm, same type, by date" comparison (with previous period / last year), sortable rankings, a per-worker table (slaughterer nevela / shot, inner treif, outer glatt / treif). Data: `archive_days` (team leader / owner) as before.

Also new in v10.16: **nightly check before work** (`plant-server/nightly-check.sh`, systemd timer). 12 checks; fixes ONLY a fixed safe list (restart a stuck API service, a fresh checked backup, clear old backups / logs when the disk is short, step the clock); everything else is reported to `plant_state.nightlyCheck` → `system_health` attention `nightly_check_problems` / `nightly_check_missing` (did not run for 30 h on a plant server), info `nightly_check_fixed`, and an optional outbound alert command. The app's "explain" button sends the report (no kashrut data) to the plant's AI edge function — explanation only, the AI never acts. Self-test fixture made independent of the plant's own state (legs sorting switched on, earlier open processing days set aside — all rolled back): it failed on a real-looking database otherwise. Self-test: + "nightly check" → **132 / 132**.

Also new in v10.16: **animal card** — `animal_card(p_token, p_date, p_n)` (team leader / owner, `_session_role`, read-only): the full board row of that day (archive, or today's live board when `p_date` is null), its processing row while the day is still in processing, the day's intake, and the event log of that number during the day. Self-test + "animal card" (station refused, bad id, unknown day) → **133 / 133**. App: a full card from the search results; every summary table exports to a .csv (Excel) file.

Still open (not changed in v10.16, please re-check our reasoning):
- **B1** rate limit per IP needs the nginx config that strips / sets `x-gt-client-ip` — the nginx file is still to be written (plant-server kit).
- **B3** worker code hashes readable by paired tablets — planned: move the hashes out of `settings_pilot` into a server-only table (worker_login already checks on the server; station logins no longer need them). Larger change, next round.
- **B5** a crash while storage is full loses the in-memory queue — the screen locks at once when storage fails (no new rulings), so at most the rulings pressed in that second; a dedicated kill/reload test is still to be added.

## Changed in v10.15 (same step 46; server sections 19, 20, 21, 22 added to the step-46 file)

Server:
- **§19 Billing currency** (`manufacturer_set_billing`, same signature and grants): upper-cased, must be `₪ $ € £` or `^[A-Z]{3}$`, else `bad_currency`. Manufacturer only, reason required, audited.
- **§20 One shared screen for the inner AND the outer check** (the plant's choice, `settings.screenConfig = '1both'`; `_gt_one_inspection()`): only then `_stage_allowed('outer')` also accepts an `inner` device, and `_nc_outer_allowed()` (rabbinate send) too. Every other configuration keeps "each station its own stage" (step 46). One screen = ONE worker list ("inspectors", stored under the inner screen's key): `_derive_actor` checks an outer ruling made in shared mode against that one list, so the logged-in worker is named on both the inner and the outer ruling. `worker_login` unchanged (the tablet's own list).
- **§21 Team-leader device lost / broken — replaced by the team leader, no manufacturer and no SQL.** `leader_recovery_code_new(p_token)` (team leader only, `_is_real_manager`): makes a 12-character recovery code (shown once; stored as a bcrypt hash in `plant_state.leaderRecoveryHash`). `leader_recovery_status(p_token)` (team leader / owner). `leader_device_replace(p_code, p_recovery)` (anon): refused from a station tablet (`station_device`); both codes must match (team-leader account code + recovery code; `code_invalid` without saying which); 5 failures an hour per address → `locked`; on success every team-leader device is disconnected (assignment cleared, keys revoked, its sessions deleted, device-log entry), the flag and the recovery code are cleared (one use), a security event is written, and `manager_login(p_code)` runs — the device then registers itself as the team-leader device exactly as at installation. `system_health` attention `leader_recovery_missing` (a team-leader device exists but no recovery code); the "second team-leader device" advice is gone.
- Self-test: + "shared inner + outer screen" (inner tablet rules outer and sends to the rabbinate only in shared mode; a worker on the one list is named on the outer ruling; a worker not on it is refused; any other config → `wrong_station`) and + "team-leader device replacement" (owner cannot make a code; from a station tablet refused; wrong recovery / wrong team-leader code refused; right codes → old device disconnected, key revoked, session gone, code used up; brake after 5 tries). **128 / 128**, PostgreSQL 16 and 17.

- **§22 Standby server and UPS (read-only visibility).** `plant_server_status(p_token)` (team leader / owner, `_session_role`): this server's name (`gt.server_name`), role (primary / standby), the streaming standbys (`_gt_standbys()` from `pg_stat_replication`, internal, not callable by the app), the sync mode, UPS status and the last takeover — all read from `plant_state`, written only by the root-run `plant-server/` tools. `system_health` gains attention `standby_down`, `standby_lag`, `ups_on_battery`, `ups_low_battery` and info `standby_async`, `failover_recent`. No new write path from the app.
- **Plant kit (`plant-server/`)**: synchronous replication A → B (a ruling is confirmed only when the standby has it); `gt-sync-watchdog.sh` drops to "main server alone" after ~6 s without the standby (work never stops) and restores sync when it returns; `promote.sh` (keepalived `notify_master`) refuses when the other server still answers as the main server or when this server cannot see the gateway; an old main server that comes back finds the other one on a newer timeline and **stops its own Postgres** (fencing; no two main servers); it returns only by `rejoin-as-standby.sh` (fresh copy). Tested on two real PostgreSQL 16 servers: 10 scenarios (see the guide §6). Please review: split-brain cases, and whether `gt_replicator` (replication + CONNECT only) is enough.
- Self-test: + "standby server and UPS" (health codes appear / disappear from `plant_state`; `plant_server_status` refused to a station device and to a bad token; `_gt_standbys` not callable). **129 / 129**, PostgreSQL 16 and 17.
App (no other new server path):
- **One-time first-installation page** (opens by itself the first time a team leader enters a plant that has not chosen its screens): recovery code → which screens work → workers of each screen → pairing the tablets → owner account → printers. Every step can be skipped (with a short note on what that means and where to do it later).
- **Installation in order:** "Choose screens" (Settings → Screens & devices). Esophagus check is chosen here (moved out of the rabbinate section). Inner/outer: separate (1 or 2 each) or one shared screen. Legs: legs + head or head only; leg sorting only with legs. Only chosen screens can be paired; a screen with a paired device cannot be un-chosen. A plant that already worked adopts its choice from its paired devices. A guide card ("Today") shows the steps with ✅.
- Team-leader screen in 5 tabs (Today / Search / Summaries / Settings / Problems); Search and Summaries are read-only (`archive_days`, `events_pilot` RLS). Settings in 7 groups. Health card shows at once; an expired session goes back to the login.

Self-test robustness (found installing on a real Supabase project): one statement, no temporary tables (transaction-local settings), runs without superuser (`gt.as_api` marker — please confirm it can only restrict), and nothing in the install files that the Supabase SQL Editor mistakes for a table without RLS (it appends `ALTER TABLE … ENABLE ROW LEVEL SECURITY` for those, which failed and rolled the run back).

## Fixed after the v10.13 review (app v10.14; the server is unchanged — still 125/125)

- A1 (a "black-hole" plant server — the request is accepted and never answered — never locked the screen: `_gtNetPing` only cleared its flag after 8 s and never recorded a failure): confirmed (40 s, no lock). `_gtNetPing` now records a failure when there is no answer within 5 s; the 15 s rule then holds. Browser test: black hole → 10 s working, 20 s locked; answers again → unlocked.
- B1 (rated A here): the sync queue lived ONLY in localStorage (`_loadSyncQueue` read it every time); when `setItem` failed the op was never queued at all → the ruling showed on the station but never reached the server, silently. Now: (1) the queue has an in-memory copy (`_memQueue`) that the pump reads, so every press is sent while the app is open; (2) on a failed write the tablet frees space it does not need (local day archives `ks_archives_*` — the server keeps every day — and the local error log) and retries; (3) still failing → the screen locks ("this tablet cannot save — work stopped, call the team leader"), retried every 2 s, unlocks by itself. Browser test: `Storage.prototype.setItem` throwing QuotaExceededError, a ruling pressed → the ruling reached the server, screen locked; storage works again → unlocked. Scripts and results: `browser-tests/`.
- The two requested extra tests are app behaviour (not SQL), so they are browser tests, not self-test rows: `browser-tests/server-lock-and-storage.test.js` + `.result.txt`.
- UI (owner's request): the cell being worked on flashes sharply — hard colour steps (no fading), bright colours, white frame, strong glow, a bigger cell; ~3 changes per second (the usual safe limit for flashing). Colours with a meaning keep it (not-chalak yellow, nevela red, inner check in progress green). `browser-tests/blink-frames.png`.

## Changed in v10.13 (same step 46): one worker list per screen; no plant server = no work

Owner's decisions:
- **Worker lists per screen.** Before: 3 shared lists (`slaughter`, `inspector` = inner + outer, `supervisor` = esophagus + legs + parts + stamps), so an inner inspector's code opened the outer screen. Now the worker role IS the screen: `slaughter, esophagus, legs, inner, outer, parts, stamps` (`_worker_role_norm`, `_stage_worker_role`, `worker_sessions_role_check`). `worker_login` accepts a code only from the list of the tablet's own screen (`wrong_station` when asking for another screen, `code_invalid` when not on that list); the 'name' mode of `_derive_actor` checks the same list. The same person may be on several lists (also with the same code). Login mode (none / name / code / both) is per screen (`loginModeByRole` keyed by screen). Saving the old shared roles is refused (`_settings_value_error`). Migration copies each old-list worker to every screen of the old list and raises `system_health` info `worker_lists_check` until the team leader saves the lists. Anyone — team leader, owner, a supervisor of another screen — enters a screen only through that screen's list (team leader / owner / manufacturer cannot log in on a station tablet at all, v10.12). No list configured = open screen (the plant's choice).
- **No plant server = no work.** The plant server is on the plant's network (the internet is not needed). A device with no answer from it for 15 s locks (full-screen notice; touches, keys, scanners and external buttons swallowed); it unlocks by itself when the server answers (a cheap `server_now_ms` ping when idle). Presses made just before the cut are still sent automatically (existing queue). Worker login only against the server (the tablet-only "unverified" login fallback is removed). No extra code / confirmation for syncing.
- Tests: worker lists per screen (inner code refused at outer, legs code at stamps, the same person on two lists, a different screen than the tablet's) and the old shared roles refused. Browser: inner inspector's code refused at the outer tablet; offline 8 s still working / 20 s locked; a ruling made during the cut reached the server after reconnect; server silent (network up) → locked, then unlocked.

## Fixed after the v10.11 review (same step 46, app v10.12)

- A1 (an owner session on a paired STATION tablet borrowed the tablet's station rights — rulings, station settings keys; the same for a manufacturer session without repair access): confirmed with a probe. Note: the session added nothing the tablet alone could not do (a paired station tablet writes for its station by design), but "the owner never writes" must hold. Fix, two layers:
  1. `manager_login`: roles `owner` / `manufacturer` through the API from a device whose `assigned_role` is a station (slaughter, esophagus, legs, inner, outer, parts, stamps) → `{ok:false, reason:'station_device'}` + security event `login_on_station_device`. A station tablet serves only its station; the owner watches from any other device. (Only layer 2 — the suggested fix — would make a station tablet on which an owner forgot to log out stop recording rulings mid-day; layer 1 prevents that state.)
  2. `_session_view_only(token)` = owner, or manufacturer while repair access is closed. `_device_write_allowed()` returns false when the request's `x-manager-token` is view-only (before any device right is considered); `push_settings` returns `unauthorized` when `p_token` or the header token is view-only.
- B: new self-test — owner AND view-only manufacturer sessions bound to each of SL1, ESO1, IN1, OUT2, LEGS, PARTS, STAMPS: the station write (claim / push), `push_settings` with the token in the header and only as `p_token` — all refused, row and settings unchanged; control: the same write from the tablet alone succeeds (the test is not vacuous). Verified: this test FAILS on the v10.11 schema and passes on v10.12. Plus: owner / manufacturer login from a station tablet refused (owner elsewhere OK).
- B: a pairing request alone creates no assignment and no credential (tested); server-only functions (`manufacturer_set_code`, `leader_account_add/remove`, `leader_device_recovery`, `_set_setup_code`) explicitly checked as not executable by `anon` / `authenticated`; recovery with two team-leader devices (both disconnected, keys revoked, sessions gone, flag cleared).
- B (installation window between `create_first_manager` and the self-pairing): not a bypass (needs the new team-leader code) — unchanged.

## Changed in v10.11 (same step 46): team-leader powers, accounts, the owner only watches

Owner's decisions: the team leader runs the plant — every setting except changing a ruling already made (screens / functions, printers / scanners, daily intake, device pairing, workers, status definitions and colours, manufacturer repair access, emergency reset with a reason, closing a processing day with a reason, reports / health) — but **can never duplicate himself**: he cannot add or remove a team leader. **The owner only watches**: every screen, report, summary and log, and he may print; he changes, deletes, copies or creates nothing — accounts included. Owner and manufacturer do not need a paired device.

- `manager_add` (new team leader) through the API: refused for everyone (`server_only`). Team-leader accounts are added / removed only on the server (SQL, the installer): `leader_account_add(name, code)` / `leader_account_remove(name)` (both raise on API requests; never the last team leader; security events `account_added` / `account_removed`).
- `manager_add_owner`: the team leader only (owner / manufacturer → unauthorized). `manager_deactivate`: the team leader, owner accounts only (a team-leader account → `server_only`); ends the account's sessions — this is how a lost owner phone is cut off (remove, add again with a new code).
- `manager_list`: team leader, and the owner read-only.
- New self-test: an owner session calls every changing RPC (push_settings, reset_daily_board, processing_day_close, support_access_set, device_unpair / manage / pair / auth_set, manager_add / add_owner / deactivate, support_force_reload, claim_animal_stage, animal_push) — every one refuses, settings and the board unchanged.
- App, owner mode: "check the system" and "AI — analyse and fix" were still shown to the owner → hidden and no-ops for an owner session; the settings tab cannot be opened by an owner even when called directly. New "🖨 Print" button on summaries / reports / log (prints only that tab, dark on white) — for the team leader and the owner.
- What the owner (and the team leader) can SEE — app only, read-only data the owner session could already read (`animals_pilot` via RLS, `archive_days`, settings): a new "Plant view" screen (`scPlant`) — every station together, live (3 s refresh): per station done / waiting / last number and a colour grid of the day's numbers; tapping a station opens its real screen in view-only mode (`gt-view-only`: `pointer-events:none` on everything but the top bar; for the owner without fading). A "Weight and charge" table on summaries and reports: today / 7 days / month / year side by side — animals weighed, kg (right + left), and, when the manufacturer enabled billing by weight, kg × price per kg (earlier days from `archive_days`). No new RPC, no new write path.
- Leader-device rule is now sticky: `_leader_devices_exist()` is also true once `plant_state.leaderDevicesRequired = '1'` (set by `device_pair(…,'leader',…)` and by the migration when a leader device exists). Removing every team-leader device therefore does NOT reopen the "any device" bootstrap. Recovery only from the server: `leader_device_recovery(reason)` (SQL only — raises on API requests): disconnects EVERY team-leader device (assignment cleared, credentials revoked, manager sessions on those devices deleted, device-log entry), clears the flag, security event. (It no longer refuses while a leader device is paired — the lost device usually still is, and nobody can log in to remove it.)
- `system_health`: `devices.leader` count, info `one_leader_device` (recommend a second one).
- App: warning before removing / retiring the last team-leader device.
- Installation (found by running a first installation on a clean server): `_set_setup_code` stored `upper(code)` with its dashes while `create_first_manager` compared the code with non-alphanumerics stripped, so a code like `ABCD-1234-XY` (the documented example) could never match. Both now use `_setup_code_norm()` (letters / digits, upper case); a hash made the old way is still accepted. New `plant_setup_needed()` (anyone; returns only whether the plant still has no team leader and, in that case, whether a setup code is configured — `manager_login` already reveals the first part via `no_managers`): a new device then shows "First installation" with one button instead of a pairing code; no dummy code has to be typed.
- Tests: self-test checks for all of the above (accounts through the app refused; server-side add / remove; owner accounts; owner view-only sweep; sticky rule + recovery of a lost, still-paired device). Browser-tested.

## Changed in v10.10 (same step 46): the team leader only from a paired team-leader device

Owner's decision: the team leader must work from a paired device.

- New pairing role `'leader'` (`devices_pilot.assigned_role`, constraint `devices_pilot_role_ok`, `_gt_value_ok('device_role')`), slots 0..3 in `device_pair`. A team-leader device is NOT a station: `_stage_allowed` gives it no stage, and `_device_write_allowed` excludes it (like `'display'`) — it writes only through a team-leader session.
- `manager_login`: a code of role `manager`, through the API (not the service key), once the plant has at least one team-leader device (`_leader_devices_exist()`: active, role leader, a non-revoked credential), is accepted only when the calling device is one (`_is_leader_device(_current_device_id())`). Otherwise: `{ok:false, reason:'leader_device_required'}`, counted as a failed attempt (same brake as wrong codes), security event `leader_device_required`. Owner (`role='owner'`) and manufacturer logins are unchanged (owner's decision).
- Bootstrap: while the plant has no team-leader device, any device may log in as team leader, and the result says `registerLeaderDevice: true`. The app then pairs THAT device as `'leader'` slot 0 (`device_request_pairing` → `device_pair(token, code, 'leader', 0)` → `device_pairing_status`). `device_pair` with `p_role='leader'` moves the calling session (bound to no device, i.e. made before any team-leader device existed) onto the new device. The first team leader can only be created with the one-time setup code (`create_first_manager`), so the first team-leader device is the device used at installation.
- More team-leader devices: an existing team leader pairs them from Settings → Screens → "Team-leader devices" (`device_pair(..., 'leader', idx)`). Unpairing one revokes its key and ends the sessions made on it (existing step-43 behaviour, now tested for leader devices).
- App: `leader_device_required` → a clear message; a device paired as `'leader'` stores no station (`ks_kiosk_role` stays empty) and opens the team-leader login / screen.
- Tests: 4 new self-test checks (bootstrap + session move, refusal from unpaired / station devices with counting + event, no ruling / station writes / worker login on a leader device, second device + unpair ends sessions). Browser-tested end to end.
- Note on the earlier B4 ("manager session from an unpaired device", answered "by design" in v10.9): superseded by this change.

## Fixed after the v10.8 review (same step 46, app v10.9)

- A1 (reset vs. a write to today's board): every function that writes animals_pilot (`animal_push`, `claim_animal_stage`, `eso_change`, `set_not_chalak_outer`, `outer_open`, `lung_drawing_set`) first takes `_board_write_lock()` = `pg_advisory_xact_lock_shared(hashtext('glatttrack_daily_rollover'))`; `request_daily_rollover` / `reset_daily_board` take the same key exclusively (as before). Taken at the start of the RPC, before any row is locked (a lock inside the trigger would deadlock with the reset's UPDATE of the same row). The board epoch is read after the lock. Writers don't wait for each other. Tested with two real concurrent connections in both orders: write-then-reset → the reset waits, the write is in the archive and the kept day; reset-then-write → the write waits and gets `stale_board`.
- A2: `create_first_manager` through the API needs the setup code: none configured → `setup_code_not_configured` (fail closed). From the server (SQL, not an API request) it still works. Installation: `select _set_setup_code('…8+ chars…');` once, before tablets connect.
- B1: new team-leader / owner codes ≥ 6 characters (`create_first_manager`, `manager_add`, `manager_add_owner`; app prompts too). Existing codes keep working.
- B3: `customStatuses` with two entries of the same key → `bad_settings` (`_settings_value_error`).
- B5 (app): `carry_push` answering `board_closed` / `earlier_day_open` → the unsent rows are written to the event log (`unsent_processing`, with board + slaughter day + the row), not dropped. Browser-tested.
- B6 (app): offline work of an ended day is kept 14 days (was 3), then written to the event log, never dropped silently.
- B4 (manager session from an unpaired device): by design — a paired device is a STATION device (ruling rights); the team leader never rules, so his phone / office PC is deliberately not a station. His session is bound to the browser (app session) it was made in, 10 h.
- Device reactivated after retirement: the app now says it must be paired again (its key was revoked when retired).

## Fixed after the v10.7 review (same step 46, app v10.8)

- A (time-only correction): `animals_pilot_guard_corrections` — a write that changes only `slaughter_time`, a final `inner_time` or `outer_time` (the ruling, its worker and its device unchanged) keeps the recorded time. Such a write used to move the device's `device_stage_cursor` back (trigger `animals_pilot_advance_cursor`) and so reopened a correction the "moved on" rule had closed. Two new self-tests; with the v10.7 guard they fail (the bypass worked), with the fix they pass.
- B3: SECURITY-MANIFEST.md header now says what it is (step-45 observed base + step-46 section from the active definitions).
- B4: each archived day keeps the status definitions it was ruled with (`daily_board_archive.statuses`, returned by `archive_days`).

## Fixed after the v10.6 review (same step 46, app v10.7)

- A1: `reset_daily_board` (the team leader's manual reset — an emergency tool, the app has no button for it) stops while slaughtered animals lack their last ruling: `{ok:false, error:'unfinished_animals', unfinished, numbers}`; it goes on only with a written `p_reason`, recorded in admin_audit with the numbers.
- A2: one transaction at a time on a kept processing board — `_proc_board_lock(p_board)` (advisory, per board) in `carry_push`, `carry_claim`, `processing_day_close` and `_proc_finalize`. Tested with two real concurrent connections in both orders.
- A3: by design — legs / head stickers are identification stickers put on every animal right after slaughter (also nevela / shot); legs SORTING is after the outer ruling (enforced). Rule 2 below says so now.
- B2: `worker_login` accepts hashed codes only.
- B3: SECURITY-MANIFEST.md step-46 section completed.
- B4: team-leader screen → Monitor: "Slaughter days in processing" (each open day, what is left per station, the station's current day in bold, a Close button with a required reason — `processing_status` / `processing_day_close`).

## What changed since v10.5 (server step 45 → 46, app v10.5 → v10.6)

1. **Stage order on the server** (every write path: `claim_animal_stage`, `animal_push`, the offline esophagus path, `set_not_chalak_outer`, `carry_push`, `carry_claim`; trigger `b_animals_stage_guard`, helper `_stage_order_error`): slaughter → esophagus (when the plant uses it, `_eso_required`) → inner → outer → legs sort / parts / stamps / weights. A number that has not reached a station cannot be ruled there (`out_of_order` + reason). A "nevela" from the esophagus after the inner check started is refused.
2. **Each station only its own stage**: `_stage_allowed('inner')` = inner station only, `('outer')` = outer station only.
3. **Kashrut configuration**: manufacturer = technical settings only; the team leader cannot change the kosher mark of / delete a custom status carried by an animal on an open board (`status_in_use`).
4. **Processing over several days, no skipping**: the daily reset keeps every slaughter day whose processing (legs / parts / stamps) is unfinished (`animals_carry`, one board per reset, linked to its archive row). Each processing station works strictly on its oldest unfinished board (`_proc_open_board`); writes to a newer board or today's board are refused (`earlier_day_open`). A board done for every station is written back into its archive row. App: the processing tablet switches its board by itself and always shows which slaughter day it works on; offline work of a day that ended is sent to that kept day.
5. **Daily rollover**: never during work (the 3-hour forced reset is gone) and never while a slaughtered animal has no last ruling (`waiting_unfinished`, health attention `rollover_waiting`). The manual reset is audited.
6. **Label mismatch**: a parts sticker / stamp that does not say the ruling is kept but recorded (`label_mismatch`, health attention).

Please check in particular:
- can any write path still rule a stage before the previous one (including INSERT … ON CONFLICT through `animal_push`, test mode, the offline esophagus path)?
- can a processing station skip an older slaughter day (live board, `carry_push`, `carry_claim`, two kept boards)?
- the trigger order on `animals_pilot` (`a_animals_merge` → `b_animals_stage_guard` → `trg_animals_pilot_guard_corrections` → `zzz_*`).
- `_do_board_reset` / `_proc_finalize`: is unfinished processing ever lost?
- the app's carry mode (`_carry`, `_carryRefresh`, `_carryPump`, `_carryKeepUnsent` in the KS module).

## Business rules the code must enforce

1. The team leader never rules on animals (only manages). Only exception: the owner's single-phone test flag, SQL-only, auto-off after 8 h.
2. The order of work is fixed: slaughter → esophagus (if used) → inner (lungs) → outer (last ruling) → processing (legs sorting, parts, stamps, weights). A number never appears at a station before it passed the earlier ones. Exception by design: legs / head identification stickers are put on every slaughtered animal right after slaughter (and the esophagus check when it applies), before inner / outer. Each station rules only its own stage; no override by anyone.
3. Correction: same device only, immediately (before that device ruled the same stage on another animal — by time), and before a later stage acted. A ruling's time never changes without the ruling itself.
4. Nevela / shot are decided only at slaughter (the esophagus check is part of the slaughter stage). A not-chalak / rabbinate animal may only be ruled Rabbinate Kosher or Treif; only an outer device can send it to the rabbinate screen, after the inner check and before any outer ruling; irreversible for the day.
5. The manufacturer never touches kashrut data or kashrut configuration; price per kg is set only by the manufacturer. Status definitions / screens are the team leader's decision, but never a ruling already made.
6. Slaughter through the outer check is one day. Processing (legs, parts, stamps, weights, later: nikur, salting, packing) may continue on later days, strictly in slaughter-day order — no skipping; the screen always shows which slaughter day is being worked on.

## Architecture

One server + database per plant (self-hosted Supabase). Tablets authenticate with a device key (`x-device-token`, stored hashed). Team-leader sessions (`x-manager-token`) are bound to the device and app session (10 h). Workers log in with a code (`worker_login`, `x-worker-token`). All writes go through server functions with optional command ids; direct table writes are revoked; triggers on `animals_pilot` are a second layer. Append-only event log with a server-computed hash chain.

## Known open items

- Central licensing server.
- Per-IP login limits trust `cf-connecting-ip` / `x-gt-client-ip` (depends on the plant's nginx overwriting them).
- Nikur / salting / packing stations; a tablet paired as inner + outer together.
