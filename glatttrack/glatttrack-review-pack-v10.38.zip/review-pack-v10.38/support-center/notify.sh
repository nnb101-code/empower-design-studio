#!/bin/bash
# GlattTrack support center — sends the alerts (v10.35). Every minute (cron / systemd timer) on any
# machine of the manufacturer that reaches the support-center database.
# Which channels: chosen on the support-center page (e-mail / SMS / WhatsApp, each on or off, with
# the addresses, and from which level: red only, or also orange). Settings of the senders: notify.env
#   CENTER_DB_URL=postgres://...            the support-center database (owner)
#   SMTP_URL=smtps://smtp.example.com:465   SMTP_USER=  SMTP_PASS=  MAIL_FROM=support@...
#   TWILIO_SID=  TWILIO_TOKEN=  SMS_FROM=+1...  WHATSAPP_FROM=+1...   (SMS and WhatsApp through Twilio)
#   DRY_RUN=1                               print instead of sending (tests)
set -u
ENV="${NOTIFY_ENV:-$(dirname "$0")/notify.env}"; [ -f "$ENV" ] && . "$ENV"
Q(){ psql "$CENTER_DB_URL" -X -q -t -A "$@"; }
Q -c "select _sc_check_silent()" >/dev/null                       # a plant that stopped reporting
declare -A HE=( [no_report]="המפעל לא מדווח (אין אינטרנט / השרת כבוי)" [standby_down]="שרת הגיבוי לא מחובר" [standby_lag]="שרת הגיבוי מפגר"
  [backup_stale]="אין גיבוי מאומת" [chain_broken]="יומן האירועים שבור" [nightly_check_problems]="בדיקת הלילה מצאה בעיות"
  [nightly_check_missing]="בדיקת הלילה לא רצה" [ups_on_battery]="אין חשמל — על סוללה" [ups_low_battery]="סוללת UPS כמעט ריקה"
  [devices_offline]="טאבלטים לא מחוברים" [tablet_offline_while_working]="טאבלט מנותק בזמן עבודה" [failed_logins]="הרבה כניסות שגויות"
  [revoked_device_writes]="מכשיר מנותק ניסה לכתוב" [rollover_waiting]="האיפוס היומי ממתין" [label_mismatch]="מדבקה שלא תואמת פסיקה" )
send_email(){ # $1 to, $2 text
  [ "${DRY_RUN:-}" = 1 ] && { echo "EMAIL → $1: $2"; return 0; }
  printf 'From: %s\nTo: %s\nSubject: =?UTF-8?B?%s?=\nContent-Type: text/plain; charset=UTF-8\n\n%s\n' "$MAIL_FROM" "$1" \
    "$(printf 'GlattTrack — %s' "${2%%:*}" | base64 -w0)" "$2" > /tmp/gt-mail.$$
  curl -s -m 30 --ssl-reqd --url "$SMTP_URL" --user "$SMTP_USER:$SMTP_PASS" --mail-from "$MAIL_FROM" --mail-rcpt "$1" --upload-file /tmp/gt-mail.$$; local rc=$?
  rm -f /tmp/gt-mail.$$; return $rc; }
send_twilio(){ # $1 to, $2 from, $3 text
  [ "${DRY_RUN:-}" = 1 ] && { echo "MSG → $1 (from $2): $3"; return 0; }
  curl -s -m 30 -f -X POST "https://api.twilio.com/2010-04-01/Accounts/$TWILIO_SID/Messages.json" -u "$TWILIO_SID:$TWILIO_TOKEN" \
    --data-urlencode "To=$1" --data-urlencode "From=$2" --data-urlencode "Body=$3" >/dev/null; }
# settings: which channels, which addresses, from which level
read -r EON SON WON MIN <<<"$(Q -c "select (settings->'email'->>'on'), (settings->'sms'->>'on'), (settings->'whatsapp'->>'on'), settings->>'minLevel' from sc_notify where id = 1" | tr '|' ' ')"
mapfile -t ETO < <(Q -c "select jsonb_array_elements_text(settings->'email'->'to') from sc_notify where id = 1")
mapfile -t STO < <(Q -c "select jsonb_array_elements_text(settings->'sms'->'to') from sc_notify where id = 1")
mapfile -t WTO < <(Q -c "select jsonb_array_elements_text(settings->'whatsapp'->'to') from sc_notify where id = 1")
# the alerts not sent yet (and still open), red always, orange only when chosen
while IFS='|' read -r id code name level text; do
  [ -n "$id" ] || continue
  [ "$level" = "warn" ] && [ "$MIN" != "warn" ] && { Q -c "update sc_alerts set sent = sent || '{\"skipped\":true}' where id = $id" >/dev/null; continue; }
  icon=$([ "$level" = bad ] && echo "🔴" || echo "🟠")
  msg="$icon מפעל #$code $name: ${HE[$text]:-$text}"
  ok_e=1; ok_s=1; ok_w=1
  if [ "$EON" = true ]; then for t in "${ETO[@]}"; do send_email "$t" "$msg" || ok_e=0; done; fi
  if [ "$SON" = true ]; then for t in "${STO[@]}"; do send_twilio "$t" "${SMS_FROM:-}" "$msg" || ok_s=0; done; fi
  if [ "$WON" = true ]; then for t in "${WTO[@]}"; do send_twilio "whatsapp:$t" "whatsapp:${WHATSAPP_FROM:-}" "$msg" || ok_w=0; done; fi
  # sent (a channel that failed is tried again next minute)
  if [ $ok_e = 1 ] && [ $ok_s = 1 ] && [ $ok_w = 1 ]; then
    Q -c "update sc_alerts set sent = sent || jsonb_build_object('at', now()::text) where id = $id" >/dev/null
  fi
done < <(Q -c "select a.id, a.code, p.name, a.level, a.text from sc_alerts a join sc_plants p on p.code = a.code
               where a.resolved_at is null and not (a.sent ? 'at') and not (a.sent ? 'skipped') order by a.id")
